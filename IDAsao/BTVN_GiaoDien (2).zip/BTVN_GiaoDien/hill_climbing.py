#https://github.com/nguyenhoangphuongnhu12/Tri_Tue_Nhan_Tao
#Nguyễn Hoàng Phương Như - 24110042
#THUẬT TOÁN LEO ĐỒI ĐƠN GIẢN (HILL CLIMBING) với h(n) = số ô rác còn lại
import tkinter as tk
import copy

# =========================================================
# LỚP BIỂU DIỄN TRẠNG THÁI MÁY HÚT BỤI
# =========================================================
class VacuumState:
    """Lưu trữ trạng thái: Vị trí robot, danh sách ô bẩn, node cha, hành động, bước và heuristic."""
    def __init__(self, agent_pos, dirty_cells, parent=None, action=None, step=0, name="S"):
        self.agent_pos = agent_pos
        self.dirty_cells = set(dirty_cells)  # Dùng set để dễ remove
        self.parent = parent
        self.action = action
        self.step = step
        self.h = len(self.dirty_cells)       # Heuristic: số ô còn bẩn
        self.name = name

    def is_goal(self):
        return len(self.dirty_cells) == 0

    def generate_successors(self, rows, cols):
        """Sinh ra các trạng thái kế tiếp với deepcopy để đảm bảo tách biệt dữ liệu hoàn toàn."""
        successors = []
        r, c = self.agent_pos
        # Thứ tự hướng đi: U, D, L, R
        moves = [("U", r-1, c), ("D", r+1, c), ("L", r, c-1), ("R", r, c+1)]
        for action, nr, nc in moves:
            if 0 <= nr < rows and 0 <= nc < cols:
                # SỬ DỤNG DEEPCOPY ĐỂ TÁCH BIỆT DỮ LIỆU
                new_dirty = copy.deepcopy(self.dirty_cells)
                if (nr, nc) in new_dirty:
                    new_dirty.remove((nr, nc)) # Robot hút bụi tại ô vừa tới
                successors.append(VacuumState((nr, nc), new_dirty, self, action, self.step + 1))
        return successors

# =========================================================
# HÀM BỔ TRỢ IN MA TRẬN CHO LOG
# =========================================================
def get_matrix_str(dirty_cells, rows=3, cols=3):
    lines = []
    for r in range(rows):
        row_str = ["1" if (r, c) in dirty_cells else "0" for c in range(cols)]
        lines.append(" ".join(row_str))
    return "\n".join(lines)

# =========================================================
# THUẬT TOÁN LEO ĐỒI (HILL CLIMBING)
# =========================================================
def hill_climbing_search(start_pos, initial_dirty, ROWS, COLS):
    start_node = VacuumState(start_pos, initial_dirty, name="S")
    path = [start_node]
    steps_log = ["--- BẮT ĐẦU THUẬT TOÁN LEO ĐỒI ---"]
    current = start_node
    node_counter = 0

    while not current.is_goal():
        successors = current.generate_successors(ROWS, COLS)
        
        # Log trạng thái hiện tại
        log_chunk = [
            f"[POP] NODE: {current.name} (Robot={current.agent_pos})",
            f"Parent: {current.parent.name if current.parent else 'None'} | Action: {current.action} | Step: {current.step} | h={current.h}",
            f"\n{get_matrix_str(current.dirty_cells, ROWS, COLS)}",
            "EXPAND & CHỌN NODE DỐC NHẤT:"
        ]
        found_next = None
        # Kiểm tra con: Chọn ngay node đầu tiên có h tốt hơn cha
        for succ in successors:
            node_counter += 1
            succ.name = chr(65 + node_counter) # Gán tên A, B, C...
            
            # --- LOG CHI TIẾT TỪNG NODE CON VỪA SINH RA ---
            log_chunk.append(f"  [PUSH NODE {succ.name}] (Robot={succ.agent_pos}) | Parent: {current.name} | Action: {succ.action} | Step: {succ.step} | h={succ.h}")
            log_chunk.append(f"\n{get_matrix_str(succ.dirty_cells, ROWS, COLS)}")
            
            # Tiêu chí leo đồi: h nhỏ hơn cha (tức sạch hơn)
            if succ.is_goal() or succ.h < current.h:
                log_chunk.append(f"-> CHỌN Node {succ.name} (h={succ.h} < cha h={current.h})")
                found_next = succ
                break # NGƯNG SINH TIẾP NGAY LẬP TỨC
            else:
                log_chunk.append(f"SKIP Node {succ.name} (h={succ.h} >= cha h={current.h})")
        
        steps_log.append("\n".join(log_chunk))

        if found_next:
            current = found_next
            path.append(current)
        else:
            steps_log.append("-> BỊ KẸT TẠI CỰC TRỊ ĐỊA PHƯƠNG!")
            break
            
    return path, steps_log

# =========================================================
# HÀM RUN CHÍNH (GIAO DIỆN TKINTER)
# =========================================================
def run(center_frame, log_text, result_text, name):
    ROWS, COLS = 3, 3  
    start_pos = (0, 0) 
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_frame.configure(bg="#ffffff")
    for widget in center_frame.winfo_children():
        widget.destroy()

    title_label = tk.Label(center_frame, text="VACUUM WORLD - Hill Climbing Search", bg="#1a1a1a", fg="#00ffcc", font=("Segoe UI", 20, "bold"), pady=8)
    title_label.pack(side="top", fill="x", pady=(10, 10))

    # Khung chú thích
    legend_bar = tk.Frame(center_frame, bg="#1a1a1a", pady=6)
    legend_bar.pack(side="top", fill="x", padx=40, pady=(0, 20))
    center_legend = tk.Frame(legend_bar, bg="#1a1a1a")
    center_legend.pack(anchor="center")
    tk.Label(center_legend, bg="#e0e0e0", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 5))
    tk.Label(center_legend, text="0 = CLEAN CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
    tk.Label(center_legend, bg="#ff6666", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="1 = DIRTY CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
    tk.Label(center_legend, bg="#3399ff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="BLUE = ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    container = tk.Frame(center_frame, bg="#ffffff")
    container.pack(expand=True)
    CELL_SIZE = 100
    canvas = tk.Canvas(container, width=COLS * CELL_SIZE, height=ROWS * CELL_SIZE, bg="#ffffff", highlightthickness=0)
    canvas.pack(side="bottom")

    path, steps_log = hill_climbing_search(start_pos, initial_dirty, ROWS, COLS)
    
    log_text.delete("1.0", tk.END)
    for log_block in steps_log:
        log_text.insert(tk.END, log_block + "\n" + "="*40 + "\n")
    log_text.see(tk.END) 
    log_text.update_idletasks()

    result_text.delete("1.0", tk.END)
    if not path or len(path) == 0:
        result_text.insert(tk.END, "Kết quả: KHÔNG TÌM THẤY ĐƯỜNG ĐI!")
        return

    path_names = [node.name for node in path]
    path_coords = [str(node.agent_pos) for node in path]
    result_text.insert(tk.END, "=== FINAL SOLUTION ===\n\n")
    result_text.insert(tk.END, f"Lộ trình các nút:\n{' -> '.join(path_names)}\n\n")
    result_text.insert(tk.END, f"Tọa độ di chuyển:\n{' -> '.join(path_coords)}\n\n")
    
    last_node = path[-1]
    if last_node.is_goal():
        result_text.insert(tk.END, "TRẠNG THÁI: THÀNH CÔNG (Đã dọn sạch)!")
    else:
        result_text.insert(tk.END, "TRẠNG THÁI: BỊ KẸT (Cực trị địa phương)!")
        
    def draw_state(state, step_index):
        canvas.delete("all")
        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                is_dirty = (r, c) in state.dirty_cells
                if (r, c) == state.agent_pos:
                    canvas.create_rectangle(x1, y1, x2, y2, fill="#3399ff", outline="white", width=3)
                    canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2 - 10, text="1" if is_dirty else "0", fill="white", font=("Consolas", 20, "bold"))
                    canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2 + 18, text="ROBOT", fill="white", font=("Segoe UI", 10, "bold"))
                else:
                    color = "#ff6666" if is_dirty else "#e0e0e0"
                    canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="#b8b8b8")
                    canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2, text="1" if is_dirty else "0", fill="#444444", font=("Consolas", 20, "bold"))
        
        if step_index > 0:
            for i in range(step_index):
                r1, c1 = path[i].agent_pos
                r2, c2 = path[i+1].agent_pos
                canvas.create_line(c1*CELL_SIZE + CELL_SIZE/2, r1*CELL_SIZE + CELL_SIZE/2, c2*CELL_SIZE + CELL_SIZE/2, r2*CELL_SIZE + CELL_SIZE/2, fill="#0022cc", width=4, arrow=tk.LAST)

    def animate(step_index):
        if step_index < len(path):
            draw_state(path[step_index], step_index)
            center_frame.after(600, lambda: animate(step_index + 1))
    animate(0)