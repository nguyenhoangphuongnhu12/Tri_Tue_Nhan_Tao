#https://github.com/nguyenhoangphuongnhu12/Tri_Tue_Nhan_Tao
#Nguyễn Hoàng Phương Như - 24110042
# Thuật toán A* với g(n) = Số bước đi tính từ nút gốc và 
# h(n) = Manhattan
import tkinter as tk
import copy
import heapq

# Biến toàn cục để tạo tên nút tự động theo thứ tự bảng chữ cái (A, B, C, D...)
node_name_counter = 0

def generate_next_node_name():
    global node_name_counter
    #Xác định quay vòng bảng chữ cái bao nhiêu lần (nếu vòng 1 thì => A1, B1..)
    cycle = node_name_counter // 26
    #Xác định vị trí chữ cái trong bảng (từ 0 đến 25).
    index = node_name_counter % 26
    char = chr(65 + index) # 65 là mã ASCII của chữ 'A'
    node_name_counter += 1
    return f"{char}{cycle}" if cycle > 0 else char


# =========================================================
# LỚP BIỂU DIỄN TRẠNG THÁI MÁY HÚT BỤI
# =========================================================
class VacuumState:
    def __init__(self, agent_pos, dirty_cells, parent=None, action=None, step=0, name="S"):
        self.agent_pos = agent_pos       # Tọa độ máy hiện tại (dòng, cột)
        self.dirty_cells = set(dirty_cells)  # Tập hợp các ô đang có rác (dòng, cột)
        self.parent = parent             # Trạng thái cha để truy vết đường đi
        self.action = action             # Hành động dẫn đến trạng thái này ('U', 'D', 'L', 'R')
        self.step = step               # g(n): Số bước đi tính từ nút gốc
        self.name = name                 # Tên định danh của nút (S, A, B, C...)
        self.h = 0                       # h(n): Khoảng cách Manhattan
        self.f = 0                       # f(n) = g(n) + h(n)

    # Hàm so sánh để heapq sắp xếp tự động (Ưu tiên f nhỏ hơn, f bằng thì g nhỏ hơn)
    def __lt__(self, other):
        if self.f != other.f:
            return self.f < other.f
        return self.step < other.step
    
    # Kiểm tra xem đã dọn sạch toàn bộ bản đồ chưa
    def is_goal(self):
        return len(self.dirty_cells) == 0

    # Chuyển trạng thái thành tuple để kiểm tra trùng
    def get_tuple(self):
        return (self.agent_pos, tuple(sorted(list(self.dirty_cells))))

    # Sinh các trạng thái con hợp lệ
    def generate_successors(self, rows, cols):
        successors = []
        r, c = self.agent_pos
        
        # Thứ tự hướng đi cố định: U, D, L, R
        moves = [
            ("U", r - 1, c),
            ("D", r + 1, c),
            ("L", r, c - 1),
            ("R", r, c + 1),
        ]
        
        for action, nr, nc in moves:
            if 0 <= nr < rows and 0 <= nc < cols:
                new_dirty = copy.deepcopy(self.dirty_cells)
                if (nr, nc) in new_dirty:
                    new_dirty.remove((nr, nc))
                
                successors.append(VacuumState(
                    agent_pos=(nr, nc), 
                    dirty_cells=new_dirty, 
                    parent=self, 
                    action=action, 
                    step=self.step + 1,
                    name="" # Sẽ gán tên chữ cái chính thức khi nạp vào Frontier
                ))
        return successors


# =========================================================
# HÀM TÍNH HEURISTIC: KHOẢNG CÁCH MANHATTAN
# =========================================================
def calculate_heuristic(agent_pos, dirty_cells):
    if not dirty_cells:
        return 0
    r, c = agent_pos
    # Khoảng cách Manhattan ngắn nhất từ vị trí robot tới ô bẩn gần nhất + tổng số ô bẩn
    min_dist = min(abs(r - dr) + abs(c - dc) for dr, dc in dirty_cells)
    return min_dist + len(dirty_cells)


# =========================================================
# HÀM BỔ TRỢ: CHUYỂN TRẠNG THÁI THÀNH MA TRẬN CHỮ ĐỂ IN LOG
# =========================================================
def get_matrix_str(dirty_cells, rows=3, cols=3):
    lines = []
    for r in range(rows):
        row_str = []
        for c in range(cols):
            row_str.append("1" if (r, c) in dirty_cells else "0")
        lines.append(" ".join(row_str))
    return "\n".join(lines)


# =========================================================
# THUẬT TOÁN TÌM KIẾM A* 
# =========================================================
def a_star_search(start_pos, initial_dirty, rows, cols):
    global node_name_counter
    node_name_counter = 0

    # Khởi tạo
    start_state = VacuumState(start_pos, initial_dirty, name="S")
    start_state.h = calculate_heuristic(start_pos, initial_dirty)
    start_state.f = start_state.step + start_state.h 

    frontier = [start_state] # Dùng heapq
    heapq.heapify(frontier)
    
    
    # reached: lưu {trạng_thái: giá_trị_g_tốt_nhất}
    reached = {start_state.get_tuple(): start_state.step}
    
    reached_history = []
    steps_log = []

    while frontier:
        # Lấy nút có f nhỏ nhất (heapq tự động chọn)
        current = heapq.heappop(frontier)
        
        # Kiểm tra tính tối ưu (Lazy removal): 
        # Nếu nút này đã được thăm với g nhỏ hơn trước đó thì bỏ qua
        # (g của hiện tại lớn hơn g trong quá khứ => bỏ qua không sinh node)
        if current.step > reached.get(current.get_tuple(), float('inf')):
            continue 
        
        reached_history.append(f"{current.name} (f={current.f})")

        # LOG POP
        log_chunk = [
            f"[POP] NODE: {current.name} (Robot={current.agent_pos})",
            f"Parent={current.parent.name if current.parent else 'None'} | Action={current.action} | g={current.step} | h={current.h} | f={current.f}",
            get_matrix_str(current.dirty_cells, rows, cols)
        ]

        if current.is_goal():
            log_chunk.append(f"-> ĐẠT ĐÍCH TẠI {current.name}!")
            steps_log.append("\n".join(log_chunk))
            path = []
            while current: path.append(current); current = current.parent
            return path[::-1], steps_log

        successors = current.generate_successors(rows, cols)
        log_chunk.append("EXPAND:")
        
        for succ in successors:
            succ.name = generate_next_node_name()
            succ.h = calculate_heuristic(succ.agent_pos, succ.dirty_cells)
            succ.f = succ.step + succ.h
            state_tuple = succ.get_tuple()
            
            # --- LOGIC CỦA CÔ (Bước d.ii và d.iii) ---
            if state_tuple not in reached or succ.step < reached[state_tuple]:
                # Cập nhật giá trị g tốt hơn vào reached
                reached[state_tuple] = succ.step
                heapq.heappush(frontier, succ)
                # Ghi log rõ ràng lý do cập nhật
                if state_tuple in reached and succ.step < reached[state_tuple]:
                    log_chunk.append(f"PUSH Node {succ.name} | Tìm thấy đường đi tối ưu hơn (g mới={succ.step} < g cũ={reached[state_tuple]}), cập nhật lại!")
                else:
                    log_chunk.append(f"PUSH Node {succ.name}")

                
            else:
                # Trạng thái đã tồn tại với g tốt hơn hoặc bằng -> BỎ QUA
                log_chunk.append(f"SKIP Node {succ.name} | Trùng trạng thái, g={succ.step} không tốt hơn {reached[state_tuple]}")
            
            log_chunk.append(get_matrix_str(succ.dirty_cells, rows, cols) + "\n")
        
        # LOG FRONTIER hiện tại
        log_chunk.append("FRONTIER (Các nút chờ trong hàng đợi):")
        # Để log nhìn đẹp, ta sắp xếp tạm thời chỉ để hiển thị
        for n in sorted(frontier):
           # Lấy tên của nút cha
            parent_name = n.parent.name if n.parent else "None"
            
            # Ghi thông tin chi tiết từng nút theo đúng yêu cầu
            log_chunk.append(
                f"Node {n.name} | Parent={parent_name} | Action={n.action} | "
                f"Step(g)={n.step} | h={n.h} | f={n.f}"
            )
            # Thêm ma trận của nút đó vào sau thông số (tùy chọn)
            log_chunk.append(get_matrix_str(n.dirty_cells, rows, cols))
            log_chunk.append("") # Dòng trống để dễ đọc
        
        log_chunk.append(f"REACHED: [{', '.join(reached_history)}]")
        log_chunk.append("=" * 60)
        steps_log.append("\n".join(log_chunk))
                
    return None, steps_log

# =========================================================
# HÀM RUN CHÍNH (GIAO DIỆN TKINTER)
# =========================================================
def run(center_frame, log_text, result_text, name):
    ROWS, COLS = 3, 3  
    start_pos = (0, 0) 
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_frame.configure(bg="#ffffff")

    for widget in center_frame.winfo_children():
        widget.destroy()

    log_text.delete("1.0", tk.END)
    result_text.delete("1.0", tk.END)

    # Tiêu đề trên ma trận
    title_label = tk.Label(
        center_frame, 
        text="VACUUM WORLD - A* APPROACH (3x3)", 
        bg="#1a1a1a", 
        fg="#00ffcc", 
        font=("Segoe UI", 20, "bold"), 
        pady=8
    )
    title_label.pack(side="top", fill="x", pady=(10, 10))

    # Khung chú thích màu sắc
    legend_bar = tk.Frame(center_frame, bg="#1a1a1a", pady=6)
    legend_bar.pack(side="top", fill="x", padx=40, pady=(0, 20))

    center_legend = tk.Frame(legend_bar, bg="#1a1a1a")
    center_legend.pack(anchor="center")

    tk.Label(center_legend, bg="#e0e0e0", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 5))
    tk.Label(center_legend, text="0 = CLEAN CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#ff6666", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="1 = DIRTY CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#3399ff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="BLUE = ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    # Khung chứa Canvas vẽ ma trận
    container = tk.Frame(center_frame, bg="#ffffff")
    container.pack(expand=True)

    CELL_SIZE = 100
    canvas = tk.Canvas(
        container, 
        width=COLS * CELL_SIZE, 
        height=ROWS * CELL_SIZE, 
        bg="#ffffff", 
        highlightthickness=0
    )
    canvas.pack(side="bottom")

    # Chạy thuật toán tìm kiếm A*
    path, steps_log = a_star_search(start_pos, initial_dirty, ROWS, COLS)

    for log_block in steps_log:
        log_text.insert(tk.END, log_block + "\n")
    log_text.see("1.0")

    if not path:
        result_text.insert(tk.END, "KHÔNG TÌM THẤY ĐƯỜNG ĐI!")
        return

    # In lộ trình cuối cùng lên màn hình Final Solution
    path_names = [node.name for node in path]
    path_coords = [str(node.agent_pos) for node in path]
    
    result_text.insert(tk.END, f"Chuỗi các Nút di chuyển:\n" + " -> ".join(path_names) + "\n\n")
    result_text.insert(tk.END, f"Tọa độ đường đi dọn dẹp:\n" + " -> ".join(path_coords))

    # =========================================================
    # HÀM CẬP NHẬT GIAO DIỆN VẼ MA TRẬN & ĐƯỜNG NỐI
    # =========================================================
    def draw_state(state, step_index):
        canvas.delete("all")
        
        # Vẽ nền ma trận
        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                
                is_dirty = (r, c) in state.dirty_cells
                matrix_val = "1" if is_dirty else "0"
                
                if (r, c) == state.agent_pos:
                    cell_bg = "#3399ff"    
                    text_color = "white"
                    cell_outline = "#ffffff"
                    width_border = 3
                else:
                    if is_dirty:
                        cell_bg = "#ff6666" 
                        text_color = "white"
                        cell_outline = "#cc5252"
                    else:
                        cell_bg = "#e0e0e0" 
                        text_color = "#444444"
                        cell_outline = "#b8b8b8"
                    width_border = 1

                canvas.create_rectangle(x1, y1, x2, y2, fill=cell_bg, outline=cell_outline, width=width_border)
                
                canvas.create_text(
                    x1 + CELL_SIZE/2, 
                    y1 + CELL_SIZE/2 - 10 if (r, c) == state.agent_pos else y1 + CELL_SIZE/2, 
                    text=matrix_val, 
                    fill=text_color, 
                    font=("Consolas", 20, "bold")
                )
                
                if (r, c) == state.agent_pos:
                    canvas.create_text(
                        x1 + CELL_SIZE/2, 
                        y1 + CELL_SIZE/2 + 18, 
                        text="ROBOT", 
                        fill="white", 
                        font=("Segoe UI", 10, "bold")
                    )

        # Vẽ nét đường đi màu xanh đậm xuyên tâm các ô lưới đã duyệt qua
        if step_index > 0:
            for i in range(step_index):
                r1, c1 = path[i].agent_pos
                r2, c2 = path[i+1].agent_pos
                
                line_x1 = c1 * CELL_SIZE + CELL_SIZE / 2
                line_y1 = r1 * CELL_SIZE + CELL_SIZE / 2
                line_x2 = c2 * CELL_SIZE + CELL_SIZE / 2
                line_y2 = r2 * CELL_SIZE + CELL_SIZE / 2
                
                canvas.create_line(line_x1, line_y1, line_x2, line_y2, fill="#0022cc", width=4, arrow=tk.LAST)

    # =========================================================
    # VÒNG LẶP HÀM ĐIỀU KHIỂN ANIMATION DIỄN HOẠT
    # =========================================================
    def animate(step_index):
        if step_index < len(path):
            current_state = path[step_index]
            draw_state(current_state, step_index)
            center_frame.after(600, lambda: animate(step_index + 1))

    animate(0)