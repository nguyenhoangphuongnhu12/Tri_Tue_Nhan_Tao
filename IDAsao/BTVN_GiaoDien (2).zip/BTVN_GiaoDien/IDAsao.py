#https://github.com/nguyenhoangphuongnhu12/Tri_Tue_Nhan_Tao#Nguyễn Hoàng Phương Như - 24110042
# Thuật toán A* với g(n) = Số bước đi tính từ nút gốc và 
# h(n) = số ô bẩn còn lại và alpha = 1
import tkinter as tk
import random
import copy

# Biến toàn cục để tạo tên nút tự động theo thứ tự bảng chữ cái (A, B, C, D...)
node_name_counter = 0

def generate_next_node_name():
    global node_name_counter
    #Xác định quay vòng bảng chữ cái bao nhiêu lần (nếu vòng 1 thì => A1, B1..)
    cycle = node_name_counter // 26
    #Xác định vị trí chữ cái trong bảng (từ 0 đến 25).
    index = node_name_counter % 26
    char = chr(65 + index) # 65 là mã ASCII của chữ 'A'
    node_name_counter += 1
    return f"{char}{cycle}" if cycle > 0 else char

# ALPHA là trọng số cho heuristic (h). f = g + alpha * h
ALPHA = 1.0 

# =========================================================
# LỚP BIỂU DIỄN TRẠNG THÁI MÁY HÚT BỤI
# =========================================================
class VacuumState:
    """Lớp lưu trữ trạng thái của máy hút bụi tại mỗi thời điểm."""
    def __init__(self, agent_pos, dirty_cells, parent=None, action=None, step=0, name='S'):
        self.agent_pos = agent_pos          # Vị trí robot (r, c)
        self.dirty_cells = frozenset(dirty_cells) # Tập các ô bẩn
        self.parent = parent                # Nút cha (để truy vết)
        self.action = action                # Hành động: Suck, L, R, U, D
        self.step = step                    # g(n): Chi phí thực tế (số bước)
        self.h = len(self.dirty_cells)      # Heuristic: số ô còn bẩn
        self.f = self.step + (ALPHA * self.h)  # Hàm đánh giá f(n)
        self.name = name

    # Kiểm tra xem đã dọn sạch toàn bộ bản đồ chưa
    def is_goal(self):
        return len(self.dirty_cells) == 0

    # Chuyển trạng thái thành tuple để kiểm tra trùng
    def get_tuple(self):
        return (self.agent_pos, tuple(sorted(list(self.dirty_cells))))

    # Hàm sinh con
    def generate_successors(self, rows, cols):
        successors = []
        r, c = self.agent_pos
        
        # Thứ tự hướng đi cố định: U, D, L, R
        moves = [
            ("U", r - 1, c),
            ("D", r + 1, c),
            ("L", r, c - 1),
            ("R", r, c + 1),
        ]
        
        for action, nr, nc in moves:
            if 0 <= nr < rows and 0 <= nc < cols:
                # SỬA Ở ĐÂY: Chuyển frozenset thành set để có thể sử dụng .remove()
                new_dirty = set(self.dirty_cells) 
                
                if (nr, nc) in new_dirty:
                    new_dirty.remove((nr, nc))
                
                # Khi tạo đối tượng VacuumState mới, nó sẽ tự động convert lại thành frozenset 
                # (vì constructor __init__ đã định nghĩa self.dirty_cells = frozenset(...))
                successors.append(VacuumState(
                    agent_pos=(nr, nc), 
                    dirty_cells=new_dirty, 
                    parent=self, 
                    action=action, 
                    step=self.step + 1,
                    name="" 
                ))
        return successors
    
# =========================================================
# HÀM BỔ TRỢ: CHUYỂN TRẠNG THÁI THÀNH MA TRẬN CHỮ ĐỂ IN LOG
# =========================================================
def get_matrix_str(dirty_cells_set, rows=3, cols=3):
    """
    Sửa lại để nhận trực tiếp frozenset (tập hợp tọa độ bẩn)
    """
    lines = []
    for r in range(rows):
        row_str = []
        for c in range(cols):
            # Kiểm tra trực tiếp trong tập hợp dirty_cells_set
            row_str.append("1" if (r, c) in dirty_cells_set else "0")
        lines.append(" ".join(row_str))
    return "\n".join(lines)

# =========================================================
# Thuật toán IDA* với ngưỡng i
# =========================================================
def ida_star_search(start_pos, initial_dirty, ROWS, COLS):
    global node_name_counter
    node_name_counter = 0
    start_node = VacuumState(start_pos, initial_dirty, name="S")
    i = start_node.f
    steps_log = []
    reached_history = []
    reached = {} 

    def search(node, current_i):
        # 1. Ghi nhật ký vào Reached History
        reached_history.append(f"{node.name} (f={node.f})")
        state_key = (node.agent_pos, node.dirty_cells)
        
        # Kiểm tra cắt tỉa
        if state_key in reached and reached[state_key] <= node.step:
            return float('inf'), None
        reached[state_key] = node.step

        # 2. LOG POP
        parent_name = node.parent.name if node.parent else "None"
        log_chunk = [
            f"[POP] NODE: {node.name} (Robot={node.agent_pos})",
            f"Parent={node.parent.name if node.parent else 'None'} | Action={node.action} | g={node.step} | h={node.h} | f={node.f}",
            get_matrix_str(node.dirty_cells, ROWS, COLS)
        ]

        if not node.dirty_cells:
            log_chunk.append(f"-> ĐẠT ĐÍCH TẠI {node.name}!")
            steps_log.append("\n".join(log_chunk))
            return "FOUND", node

        if node.f > current_i:
            steps_log.append("\n".join(log_chunk) + f"\n-> Vượt ngưỡng i={current_i}, CẮT NHÁNH!\n" + "="*60)
            return node.f, None

        # 3. EXPAND & PUSH/SKIP
        successors = node.generate_successors(ROWS, COLS)
        log_chunk.append("EXPAND:")
        current_frontier = []
        
        for succ in successors:
            succ.name = generate_next_node_name()
            s_key = (succ.agent_pos, succ.dirty_cells)
            
            if s_key not in reached or succ.step < reached.get(s_key, float('inf')):
                log_chunk.append(f"PUSH Node {succ.name} | Parent={parent_name} | Action={succ.action} | Step(g)={succ.step} | h={succ.h} | f={succ.f}")
                log_chunk.append(get_matrix_str(succ.dirty_cells, ROWS, COLS) + "\n")
                
                current_frontier.append(succ)
            else:
                log_chunk.append(f"SKIP Node {succ.name} | Trùng trạng thái, g={succ.step} không tốt hơn")
            log_chunk.append(get_matrix_str(succ.dirty_cells, ROWS, COLS) + "\n")

        # 4. Ghi FRONTIER chi tiết
        log_chunk.append("FRONTIER (Các nút chờ trong hàng đợi):")
        for n in current_frontier:
            parent_name = n.parent.name if n.parent else "None"
            log_chunk.append(f"Node {n.name} | Parent={parent_name} | Action={succ.action} | Step(g)={succ.step} | h={succ.h} | f={succ.f}")
            log_chunk.append(get_matrix_str(n.dirty_cells, ROWS, COLS) + "\n")

        log_chunk.append(f"REACHED: [{', '.join(reached_history)}]")
        log_chunk.append("=" * 60)
        steps_log.append("\n".join(log_chunk))

        # 5. Đệ quy
        min_next = float('inf')
        for succ in sorted(current_frontier, key=lambda x: x.f):
            res, final = search(succ, current_i)
            if res == "FOUND": return "FOUND", final
            min_next = min(min_next, res)
        return min_next, None

    while i < float('inf'):
        reached = {}
        steps_log.append(f"--- Ngưỡng i = {i:.1f} ---")
        result, final_node = search(start_node, i)
        if result == "FOUND":
            path = []
            while final_node:
                path.insert(0, final_node)
                final_node = final_node.parent
            return path, steps_log
        i = result
    return None, steps_log

# =========================================================
# HÀM RUN CHÍNH (GIAO DIỆN TKINTER)
# =========================================================
def run(center_frame, log_text, result_text, name):
    ROWS, COLS = 3, 3  
    start_pos = (0, 0) 
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_frame.configure(bg="#ffffff")

    for widget in center_frame.winfo_children():
        widget.destroy()

    log_text.delete("1.0", tk.END)
    result_text.delete("1.0", tk.END)

    # Tiêu đề trên ma trận
    title_label = tk.Label(
        center_frame, 
        text="VACUUM WORLD - A* APPROACH (3x3)", 
        bg="#1a1a1a", 
        fg="#00ffcc", 
        font=("Segoe UI", 20, "bold"), 
        pady=8
    )
    title_label.pack(side="top", fill="x", pady=(10, 10))

    # Khung chú thích màu sắc
    legend_bar = tk.Frame(center_frame, bg="#1a1a1a", pady=6)
    legend_bar.pack(side="top", fill="x", padx=40, pady=(0, 20))

    center_legend = tk.Frame(legend_bar, bg="#1a1a1a")
    center_legend.pack(anchor="center")

    tk.Label(center_legend, bg="#e0e0e0", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 5))
    tk.Label(center_legend, text="0 = CLEAN CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#ff6666", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="1 = DIRTY CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#3399ff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="BLUE = ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    # Khung chứa Canvas vẽ ma trận
    container = tk.Frame(center_frame, bg="#ffffff")
    container.pack(expand=True)

    CELL_SIZE = 100
    canvas = tk.Canvas(
        container, 
        width=COLS * CELL_SIZE, 
        height=ROWS * CELL_SIZE, 
        bg="#ffffff", 
        highlightthickness=0
    )
    canvas.pack(side="bottom")

    # Chạy thuật toán tìm kiếm A*
    path, steps_log = ida_star_search(start_pos, initial_dirty, ROWS, COLS)

    for log_block in steps_log:
        log_text.insert(tk.END, log_block + "\n")
    log_text.see("1.0")

    if not path:
        result_text.insert(tk.END, "KHÔNG TÌM THẤY ĐƯỜNG ĐI!")
        return

    # In lộ trình cuối cùng lên màn hình Final Solution
    path_names = [node.name for node in path]
    path_coords = [str(node.agent_pos) for node in path]
    
    result_text.insert(tk.END, f"Chuỗi các Nút di chuyển:\n" + " -> ".join(path_names) + "\n\n")
    result_text.insert(tk.END, f"Tọa độ đường đi dọn dẹp:\n" + " -> ".join(path_coords))

    # =========================================================
    # HÀM CẬP NHẬT GIAO DIỆN VẼ MA TRẬN & ĐƯỜNG NỐI
    # =========================================================
    def draw_state(state, step_index):
        canvas.delete("all")
        
        # Vẽ nền ma trận
        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                
                is_dirty = (r, c) in state.dirty_cells
                matrix_val = "1" if is_dirty else "0"
                
                if (r, c) == state.agent_pos:
                    cell_bg = "#3399ff"    
                    text_color = "white"
                    cell_outline = "#ffffff"
                    width_border = 3
                else:
                    if is_dirty:
                        cell_bg = "#ff6666" 
                        text_color = "white"
                        cell_outline = "#cc5252"
                    else:
                        cell_bg = "#e0e0e0" 
                        text_color = "#444444"
                        cell_outline = "#b8b8b8"
                    width_border = 1

                canvas.create_rectangle(x1, y1, x2, y2, fill=cell_bg, outline=cell_outline, width=width_border)
                
                canvas.create_text(
                    x1 + CELL_SIZE/2, 
                    y1 + CELL_SIZE/2 - 10 if (r, c) == state.agent_pos else y1 + CELL_SIZE/2, 
                    text=matrix_val, 
                    fill=text_color, 
                    font=("Consolas", 20, "bold")
                )
                
                if (r, c) == state.agent_pos:
                    canvas.create_text(
                        x1 + CELL_SIZE/2, 
                        y1 + CELL_SIZE/2 + 18, 
                        text="ROBOT", 
                        fill="white", 
                        font=("Segoe UI", 10, "bold")
                    )

        # Vẽ nét đường đi màu xanh đậm xuyên tâm các ô lưới đã duyệt qua
        if step_index > 0:
            for i in range(step_index):
                r1, c1 = path[i].agent_pos
                r2, c2 = path[i+1].agent_pos
                
                line_x1 = c1 * CELL_SIZE + CELL_SIZE / 2
                line_y1 = r1 * CELL_SIZE + CELL_SIZE / 2
                line_x2 = c2 * CELL_SIZE + CELL_SIZE / 2
                line_y2 = r2 * CELL_SIZE + CELL_SIZE / 2
                
                canvas.create_line(line_x1, line_y1, line_x2, line_y2, fill="#0022cc", width=4, arrow=tk.LAST)

    # =========================================================
    # VÒNG LẶP HÀM ĐIỀU KHIỂN ANIMATION DIỄN HOẠT
    # =========================================================
    def animate(step_index):
        if step_index < len(path):
            current_state = path[step_index]
            draw_state(current_state, step_index)
            center_frame.after(600, lambda: animate(step_index + 1))

    animate(0)