#https://github.com/nguyenhoangphuongnhu12/Tri_Tue_Nhan_Tao
#Nguyễn Hoàng Phương Như - 24110042
#THUẬT TOÁN LEO ĐỒI NGẪU NHIÊN (STOCHASTIC HILL CLIMBING) với h(n) = số ô rác còn lại
import tkinter as tk
import copy
import random

# =========================================================
# LỚP BIỂU DIỄN TRẠNG THÁI MÁY HÚT BỤI
# =========================================================
class VacuumState:
    def __init__(self, agent_pos, dirty_cells, parent=None, action=None, step=0, name="S"):
        self.agent_pos = agent_pos
        self.dirty_cells = set(dirty_cells)
        self.parent = parent
        self.action = action
        self.step = step
        self.h = len(self.dirty_cells)
        self.name = name

    def is_goal(self):
        return len(self.dirty_cells) == 0

    def generate_successors(self, rows, cols):
        """Sinh ra trạng thái kế tiếp sử dụng deepcopy để tách biệt dữ liệu."""
        successors = []
        r, c = self.agent_pos
        moves = [("U", r-1, c), ("D", r+1, c), ("L", r, c-1), ("R", r, c+1)]
        
        for action, nr, nc in moves:
            if 0 <= nr < rows and 0 <= nc < cols:
                # Dùng deepcopy cho set để đảm bảo node con độc lập hoàn toàn
                new_dirty = copy.deepcopy(self.dirty_cells)
                if (nr, nc) in new_dirty:
                    new_dirty.remove((nr, nc))
                
                successors.append(VacuumState((nr, nc), new_dirty, self, action, self.step + 1))
        return successors

# =========================================================
# HÀM BỔ TRỢ
# =========================================================
def get_matrix_str(dirty_cells, rows=3, cols=3):
    lines = []
    for r in range(rows):
        row_str = ["1" if (r, c) in dirty_cells else "0" for c in range(cols)]
        lines.append(" ".join(row_str))
    return "\n".join(lines)

# =========================================================
# THUẬT TOÁN LEO ĐỒI NGẪU NHIÊN (STOCHASTIC HILL CLIMBING)
# =========================================================
def stochastic_hill_climbing_search(start_pos, initial_dirty, ROWS, COLS):
    start_node = VacuumState(start_pos, initial_dirty, name="S")
    path = [start_node]
    steps_log = ["--- BẮT ĐẦU LEO ĐỒI NGẪU NHIÊN ---"]
    current = start_node
    node_counter = 0

    while not current.is_goal():
        successors = current.generate_successors(ROWS, COLS)
        
        log_chunk = [
            f"[POP] NODE: {current.name} (Robot={current.agent_pos})",
            f"Parent: {current.parent.name if current.parent else 'None'} | Action: {current.action} | h={current.h}",
            f"\n{get_matrix_str(current.dirty_cells, ROWS, COLS)}",
            "EXPAND & CHỌN NGẪU NHIÊN NODE TỐT HƠN:"
        ]

        better_successors = []
        for succ in successors:
            node_counter += 1
            succ.name = chr(65 + node_counter)
            
            # Log thông tin node con vừa sinh ra
            log_chunk.append(f"  [NODE CON {succ.name}] (Robot={succ.agent_pos}) | h={succ.h}")
            log_chunk.append(f"  \n{get_matrix_str(succ.dirty_cells, ROWS, COLS)}")
            
            
            if succ.h < current.h:
                better_successors.append(succ)
        
        if better_successors:
            chosen = random.choice(better_successors)
            log_chunk.append(f"-> CHỌN NGẪU NHIÊN Node {chosen.name} (h={chosen.h} trong số {len(better_successors)} node tốt hơn)")
            steps_log.append("\n".join(log_chunk))
            current = chosen
            path.append(current)
        else:
            log_chunk.append("-> KHÔNG CÓ LỰA CHỌN TỐT HƠN -> DỪNG LẠI!")
            steps_log.append("\n".join(log_chunk))
            break
            
    return path, steps_log

# =========================================================
# HÀM RUN CHÍNH (GIAO DIỆN TKINTER)
# =========================================================
def run(center_frame, log_text, result_text, name):
    ROWS, COLS = 3, 3  
    start_pos = (0, 0) 
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_frame.configure(bg="#ffffff")

    for widget in center_frame.winfo_children():
        widget.destroy()

    log_text.delete("1.0", tk.END)
    result_text.delete("1.0", tk.END)

    # Tiêu đề trên ma trận
    title_label = tk.Label(
        center_frame, 
        text="VACUUM WORLD - Steepest Hill Climbing Search", 
        bg="#1a1a1a", 
        fg="#00ffcc", 
        font=("Segoe UI", 20, "bold"), 
        pady=8
    )
    title_label.pack(side="top", fill="x", pady=(10, 10))

    # Khung chú thích màu sắc
    legend_bar = tk.Frame(center_frame, bg="#1a1a1a", pady=6)
    legend_bar.pack(side="top", fill="x", padx=40, pady=(0, 20))

    center_legend = tk.Frame(legend_bar, bg="#1a1a1a")
    center_legend.pack(anchor="center")

    tk.Label(center_legend, bg="#e0e0e0", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 5))
    tk.Label(center_legend, text="0 = CLEAN CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#ff6666", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="1 = DIRTY CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#3399ff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="BLUE = ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    # Khung chứa Canvas vẽ ma trận
    container = tk.Frame(center_frame, bg="#ffffff")
    container.pack(expand=True)

    CELL_SIZE = 100
    canvas = tk.Canvas(
        container, 
        width=COLS * CELL_SIZE, 
        height=ROWS * CELL_SIZE, 
        bg="#ffffff", 
        highlightthickness=0
    )
    canvas.pack(side="bottom")

    # Thay dòng gọi cũ bằng dòng này:
    path, steps_log = stochastic_hill_climbing_search(start_pos, initial_dirty, ROWS, COLS)
    
    # In log chi tiết
    log_text.delete("1.0", tk.END) # Đảm bảo xóa trắng trước khi in mới
    for log_block in steps_log:
        log_text.insert(tk.END, log_block + "\n" + "="*40 + "\n")
    
    # THÊM DÒNG NÀY ĐỂ TỰ ĐỘNG CUỘN XUỐNG DƯỚI CÙNG
    log_text.see(tk.END) 
    # THÊM DÒNG NÀY ĐỂ ÉP GIAO DIỆN CẬP NHẬT NGAY LẬP TỨC
    log_text.update_idletasks()

    # 1. Dọn dẹp ô hiển thị kết quả
    result_text.delete("1.0", tk.END)

    # 2. Xử lý logic hiển thị Final Solution
    if not path or len(path) == 0:
        result_text.insert(tk.END, "Kết quả: KHÔNG TÌM THẤY ĐƯỜNG ĐI!")
        return

    # Lấy thông tin lộ trình
    path_names = [node.name for node in path]
    path_coords = [str(node.agent_pos) for node in path]
    
    # In ra khung result_text
    result_text.insert(tk.END, "=== FINAL SOLUTION ===\n\n")
    result_text.insert(tk.END, f"Lộ trình các nút:\n{' -> '.join(path_names)}\n\n")
    result_text.insert(tk.END, f"Tọa độ di chuyển:\n{' -> '.join(path_coords)}\n\n")
    
    # Kiểm tra trạng thái cuối cùng
    last_node = path[-1]
    if last_node.is_goal():
        result_text.insert(tk.END, "TRẠNG THÁI: THÀNH CÔNG (Đã dọn sạch)!")
        result_text.tag_config("success", foreground="green")
        result_text.tag_add("success", "1.0", "end")
    else:
        result_text.insert(tk.END, "TRẠNG THÁI: BỊ KẸT (Cực trị địa phương)!")
        result_text.tag_config("fail", foreground="red")
        result_text.tag_add("fail", "1.0", "end")
        
    # =========================================================
    # HÀM CẬP NHẬT GIAO DIỆN VẼ MA TRẬN & ĐƯỜNG NỐI
    # =========================================================
    def draw_state(state, step_index):
        canvas.delete("all")
        
        # Vẽ nền ma trận
        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                
                is_dirty = (r, c) in state.dirty_cells
                matrix_val = "1" if is_dirty else "0"
                
                if (r, c) == state.agent_pos:
                    cell_bg = "#3399ff"    
                    text_color = "white"
                    cell_outline = "#ffffff"
                    width_border = 3
                else:
                    if is_dirty:
                        cell_bg = "#ff6666" 
                        text_color = "white"
                        cell_outline = "#cc5252"
                    else:
                        cell_bg = "#e0e0e0" 
                        text_color = "#444444"
                        cell_outline = "#b8b8b8"
                    width_border = 1

                canvas.create_rectangle(x1, y1, x2, y2, fill=cell_bg, outline=cell_outline, width=width_border)
                
                canvas.create_text(
                    x1 + CELL_SIZE/2, 
                    y1 + CELL_SIZE/2 - 10 if (r, c) == state.agent_pos else y1 + CELL_SIZE/2, 
                    text=matrix_val, 
                    fill=text_color, 
                    font=("Consolas", 20, "bold")
                )
                
                if (r, c) == state.agent_pos:
                    canvas.create_text(
                        x1 + CELL_SIZE/2, 
                        y1 + CELL_SIZE/2 + 18, 
                        text="ROBOT", 
                        fill="white", 
                        font=("Segoe UI", 10, "bold")
                    )

        # Vẽ nét đường đi màu xanh đậm xuyên tâm các ô lưới đã duyệt qua
        if step_index > 0:
            for i in range(step_index):
                r1, c1 = path[i].agent_pos
                r2, c2 = path[i+1].agent_pos
                
                line_x1 = c1 * CELL_SIZE + CELL_SIZE / 2
                line_y1 = r1 * CELL_SIZE + CELL_SIZE / 2
                line_x2 = c2 * CELL_SIZE + CELL_SIZE / 2
                line_y2 = r2 * CELL_SIZE + CELL_SIZE / 2
                
                canvas.create_line(line_x1, line_y1, line_x2, line_y2, fill="#0022cc", width=4, arrow=tk.LAST)

    # =========================================================
    # VÒNG LẶP HÀM ĐIỀU KHIỂN ANIMATION DIỄN HOẠT
    # =========================================================
    def animate(step_index):
        if step_index < len(path):
            current_state = path[step_index]
            draw_state(current_state, step_index)
            center_frame.after(600, lambda: animate(step_index + 1))

    animate(0)