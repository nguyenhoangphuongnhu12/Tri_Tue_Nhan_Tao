#Nguyễn Hoàng Phương Như - 24110042
import tkinter as tk

# =====================================================
# DFS APPROACH 1
# FULL STATE VACUUM WORLD
# ADD REACHED AFTER POP
# =====================================================

def run(center_frame, log_text, result_text, algo_name):

    # =================================================
    # CLEAR UI
    # =================================================
    for w in center_frame.winfo_children():
        w.destroy()

    log_text.delete("1.0", "end")
    result_text.delete("1.0", "end")

    # =================================================
    # TITLE
    # =================================================
    tk.Label(
        center_frame,
        text="VACUUM WORLD - DFS APPROACH 1",
        bg="#1e1e1e",
        fg="#00ffcc",
        font=("Segoe UI", 18, "bold")
    ).pack(pady=10)

    # =================================================
    # LEGEND
    # =================================================
    legend_frame = tk.Frame(
        center_frame,
        bg="#1e1e1e"
    )

    legend_frame.pack(pady=5)

    legends = [
        ("0 = CLEAN CELL", "#dddddd"),
        ("1 = DIRTY CELL", "#ff6666"),
        ("BLUE = ROBOT", "#3399ff")
    ]

    for text, color in legends:

        item = tk.Frame(
            legend_frame,
            bg="#1e1e1e"
        )

        item.pack(side="left", padx=15)

        tk.Canvas(
            item,
            width=20,
            height=20,
            bg=color,
            highlightthickness=1,
            highlightbackground="black"
        ).pack(side="left", padx=5)

        tk.Label(
            item,
            text=text,
            fg="white",
            bg="#1e1e1e",
            font=("Consolas", 10, "bold")
        ).pack(side="left")

    # =================================================
    # INITIAL GRID
    # =================================================
    initial_grid = (
        (0, 1, 0),
        (1, 1, 0),
        (0, 0, 1)
    )

    rows = 3
    cols = 3
    size = 100

    # =================================================
    # CANVAS
    # =================================================
    canvas = tk.Canvas(
        center_frame,
        bg="white"
    )

    canvas.pack(fill="both", expand=True)

    canvas.update()

    offset_x = (
        canvas.winfo_width() - cols * size
    ) // 2

    offset_y = (
        canvas.winfo_height() - rows * size
    ) // 2

    cells = {}
    texts = {}
    centers = {}

    # =================================================
    # DRAW GRID
    # =================================================
    for r in range(rows):
        for c in range(cols):

            x1 = offset_x + c * size
            y1 = offset_y + r * size
            x2 = x1 + size
            y2 = y1 + size

            color = (
                "#ff6666"
                if initial_grid[r][c] == 1
                else "#dddddd"
            )

            cells[(r, c)] = canvas.create_rectangle(
                x1, y1, x2, y2,
                fill=color,
                outline="black",
                width=2
            )

            texts[(r, c)] = canvas.create_text(
                (x1+x2)//2,
                (y1+y2)//2,
                text=str(initial_grid[r][c]),
                font=("Consolas", 16, "bold")
            )

            centers[(r, c)] = (
                (x1+x2)//2,
                (y1+y2)//2
            )

    # =================================================
    # ROBOT
    # =================================================
    robot = canvas.create_rectangle(
        0, 0, 0, 0,
        fill="#3399ff"
    )

    # =================================================
    # MOVE ROBOT
    # =================================================
    def move_robot(r, c):

        robot_size = 50

        cx, cy = centers[(r, c)]

        x1 = cx - robot_size // 2
        y1 = cy - robot_size // 2

        x2 = cx + robot_size // 2
        y2 = cy + robot_size // 2

        canvas.coords(robot, x1, y1, x2, y2)

    move_robot(0, 0)

    # =================================================
    # GOAL TEST
    # =================================================
    def is_goal(grid):

        for row in grid:
            for cell in row:

                if cell == 1:
                    return False

        return True

    # =================================================
    # CLEAN GRID
    # =================================================
    def clean_grid(grid, r, c):

        new_grid = [list(row) for row in grid]

        new_grid[r][c] = 0

        return tuple(tuple(row) for row in new_grid)

    # =================================================
    # FORMAT GRID
    # =================================================
    def grid_to_string(grid):

        s = ""

        for row in grid:
            s += " ".join(map(str, row)) + "\n"

        return s

    # =================================================
    # DFS APPROACH 1
    # =================================================
    def dfs():

        start_state = (
            (0, 0),
            initial_grid
        )

        stack = []

        stack.append({
            "state": start_state,
            "parent": None,
            "action": None,
            "step": 0,
            "path": [start_state]
        })

        # =============================================
        # REACHED
        # add only after POP
        # =============================================
        reached = set()

        while stack:

            # =========================================
            # POP
            # =========================================
            node = stack.pop()

            (r, c), grid = node["state"]

            # =========================================
            # ADD REACHED AFTER POP
            # =========================================
            reached.add(node["state"])

            # =========================================
            # LOG POP
            # =========================================
            log_text.insert(
                "end",
                f"\n[POP] ROBOT={r,c}\n"
            )

            log_text.insert(
                "end",
                f"Parent: {node['parent']}\n"
            )

            log_text.insert(
                "end",
                f"Action: {node['action']}\n"
            )

            log_text.insert(
                "end",
                f"Step  : {node['step']}\n\n"
            )

            log_text.insert(
                "end",
                grid_to_string(grid)
            )

            # =========================================
            # GOAL CHECK
            # =========================================
            if is_goal(grid):

                log_text.insert(
                    "end",
                    "\nGOAL FOUND AFTER POP\n"
                )

                log_text.insert(
                    "end",
                    "=========================\n"
                )

                return node["path"]

            # =========================================
            # EXPAND
            # =========================================
            log_text.insert(
                "end",
                "\nEXPAND:\n"
            )

            directions = [
                ("U", -1, 0),
                ("L", 0, -1),
                ("D", 1, 0),
                ("R", 0, 1)
            ]

            for act, dr, dc in directions:

                nr = r + dr
                nc = c + dc

                if 0 <= nr < rows and 0 <= nc < cols:

                    new_grid = clean_grid(
                        grid,
                        nr,
                        nc
                    )

                    child_state = (
                        (nr, nc),
                        new_grid
                    )

                    # =================================
                    # CHECK DUPLICATE IN STACK
                    # =================================
                    in_stack = False

                    for s in stack:

                        if s["state"] == child_state:
                            in_stack = True
                            break

                    # =================================
                    # PUSH IF NOT VISITED
                    # =================================
                    if (
                        child_state not in reached
                        and not in_stack
                    ):

                        child_node = {
                            "state": child_state,
                            "parent": node["state"],
                            "action": act,
                            "step": node["step"] + 1,
                            "path": (
                                node["path"] +
                                [child_state]
                            )
                        }

                        stack.append(child_node)

                        # =============================
                        # LOG PUSH
                        # =============================
                        log_text.insert(
                            "end",
                            f"\nPUSH {(nr,nc)} "
                            f"| A={act} "
                            f"| S={node['step']+1}\n"
                        )

                        log_text.insert(
                            "end",
                            grid_to_string(new_grid)
                        )

            # =========================================
            # STACK
            # =========================================
            log_text.insert(
                "end",
                "\nSTACK:\n"
            )

            if len(stack) == 0:

                log_text.insert(
                    "end",
                    "EMPTY\n"
                )

            else:
                log_text.insert(
                    "end",
                    "\n----- TOP -----\n"
                )

                for s in reversed(stack):

                    pos, g = s["state"]

                    log_text.insert(
                        "end",
                        f"\n{pos} "
                        f"| A={s['action']} "
                        f"| S={s['step']}\n"
                    )

                    log_text.insert(
                        "end",
                        grid_to_string(g)
                    )
                    
                log_text.insert(
                    "end",
                    "----- BOTTOM -----\n"
                )

            # =========================================
            # REACHED
            # =========================================
            log_text.insert(
                "end",
                "\nREACHED:\n"
            )

            for item in reached:

                pos, g = item

                log_text.insert(
                    "end",
                    f"\nROBOT={pos}\n"
                )

                log_text.insert(
                    "end",
                    grid_to_string(g)
                )

            log_text.insert(
                "end",
                "-------------------------\n"
            )

            log_text.see("end")

        return None

    # =================================================
    # RUN DFS
    # =================================================
    solution_path = dfs()

    # =================================================
    # NO SOLUTION
    # =================================================
    if solution_path is None:

        result_text.insert(
            "end",
            "NO SOLUTION"
        )

        return

    # =================================================
    # ANIMATION
    # =================================================
    def animate(index):

        if index >= len(solution_path):

            result_text.insert(
                "end",
                "ALL CLEAN!\n\n"
            )

            result_text.insert(
                "end",
                "PATH:\n\n"
            )

            shortest_path = []

            for state in solution_path:

                pos, _ = state
                shortest_path.append(str(pos))

            result_text.insert(
                "end",
                " -> ".join(shortest_path)
            )

            result_text.insert(
                "end",
                f"\n\nTOTAL STEPS: "
                f"{len(shortest_path)-1}"
            )

            return

        (r, c), grid = solution_path[index]

        move_robot(r, c)

        # =========================================
        # UPDATE GRID
        # =========================================
        for rr in range(rows):
            for cc in range(cols):

                val = grid[rr][cc]

                canvas.itemconfig(
                    texts[(rr, cc)],
                    text=str(val)
                )

                color = (
                    "#ff6666"
                    if val == 1
                    else "#dddddd"
                )

                canvas.itemconfig(
                    cells[(rr, cc)],
                    fill=color
                )

        # =========================================
        # DRAW PATH
        # =========================================
        if index > 0:

            (pr, pc), _ = solution_path[index - 1]

            x1, y1 = centers[(pr, pc)]
            x2, y2 = centers[(r, c)]

            canvas.create_line(
                x1, y1,
                x2, y2,
                width=4,
                fill="blue"
            )

        center_frame.after(
            700,
            lambda: animate(index + 1)
        )

    animate(0)