import tkinter as tk
from tkinter.scrolledtext import ScrolledText
import os
import importlib

# =========================================================
# LOAD ALGORITHMS (FIX PATH)
# =========================================================

algorithms = {}

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

for file in os.listdir(BASE_DIR):
    if file.endswith(".py") and file != "main.py":

        name = file[:-3]

        try:
            module = importlib.import_module(name)
            importlib.reload(module)

            if hasattr(module, "run"):
                display_name = name.replace("_", " ").upper()
                algorithms[display_name] = module.run

        except Exception as e:
            print(f"Lỗi load {name}: {e}")

print("Loaded algorithms:", algorithms)

# =========================================================
# WINDOW
# =========================================================

root = tk.Tk()
root.title("AI Algorithm Visualizer")
root.geometry("1400x800")
root.configure(bg="#121212")

MENU_WIDTH = 240
active_button = None
menu_visible = False

# =========================================================
# TOP BAR
# =========================================================

top_bar = tk.Frame(root, bg="#1f1f1f", height=50)
top_bar.pack(side="top", fill="x")

# =========================================================
# MAIN AREA
# =========================================================

main_container = tk.Frame(root, bg="#121212")
main_container.pack(fill="both", expand=True)

# CENTER
center_frame = tk.Frame(main_container, bg="#1e1e1e")
center_frame.pack(side="left", fill="both", expand=True, padx=10, pady=10)

# LOG (CHỈ 1 CỘT DUY NHẤT)
log_frame = tk.Frame(main_container, bg="#1a1a1a", width=350)
log_frame.pack(side="right", fill="y", padx=(0,10), pady=10)

log_title = tk.Label(
    log_frame,
    text="PROCESS LOG",
    bg="#1a1a1a",
    fg="#ffcc00",
    font=("Segoe UI", 14, "bold")
)
log_title.pack(anchor="w", padx=10, pady=10)

log_text = ScrolledText(
    log_frame,
    bg="#111111",
    fg="#00ffcc",
    insertbackground="white",
    font=("Consolas", 11),
    relief="flat"
)
log_text.pack(fill="both", expand=True, padx=10, pady=(0,10))

# =========================================================
# BOTTOM
# =========================================================

bottom_frame = tk.Frame(root, bg="#0f0f0f", height=120)
bottom_frame.pack(side="bottom", fill="x")

solution_title = tk.Label(
    bottom_frame,
    text="FINAL SOLUTION",
    bg="#0f0f0f",
    fg="#00ff66",
    font=("Segoe UI", 14, "bold")
)
solution_title.pack(anchor="w", padx=15, pady=(10,5))

result_text = tk.Text(
    bottom_frame,
    height=4,
    bg="#111111",
    fg="white",
    font=("Consolas", 12),
    relief="flat"
)
result_text.pack(fill="x", padx=15, pady=(0,10))

# =========================================================
# SIDE MENU (SLIDE)
# =========================================================

side_menu = tk.Frame(root, bg="#202020", width=MENU_WIDTH)

side_menu.place(x=-MENU_WIDTH, y=50, relheight=1)

menu_title = tk.Label(
    side_menu,
    text="THUẬT TOÁN",
    bg="#202020",
    fg="white",
    font=("Segoe UI", 16, "bold")
)
menu_title.pack(pady=20)

# =========================================================
# ANIMATION
# =========================================================

def slide_in(x=-MENU_WIDTH):
    if x < 0:
        side_menu.place(x=x, y=50)
        root.after(5, lambda: slide_in(x + 20))
    else:
        side_menu.place(x=0, y=50)

def slide_out(x=0):
    if x > -MENU_WIDTH:
        side_menu.place(x=x, y=50)
        root.after(5, lambda: slide_out(x - 20))
    else:
        side_menu.place(x=-MENU_WIDTH, y=50)

def toggle_menu():
    global menu_visible
    if menu_visible:
        slide_out()
    else:
        slide_in()
    menu_visible = not menu_visible

# =========================================================
# TOP BAR CONTENT
# =========================================================

menu_btn = tk.Button(
    top_bar,
    text="☰",
    font=("Segoe UI", 18),
    bg="#1f1f1f",
    fg="white",
    bd=0,
    activebackground="#333333",
    command=toggle_menu
)
menu_btn.pack(side="left", padx=15)

title = tk.Label(
    top_bar,
    text="AI ALGORITHM",
    bg="#1f1f1f",
    fg="white",
    font=("Segoe UI", 16, "bold")
)
title.pack(side="left")

# =========================================================
# CREATE BUTTONS (THIẾU ĐOẠN NÀY)
# =========================================================
for name, func in algorithms.items():

    btn = tk.Button(
        side_menu,
        text=name,
        bg="#2d2d2d",
        fg="white",
        relief="flat",
        font=("Segoe UI", 12),
        pady=10,
        activebackground="#4caf50"
    )

    # CLICK
    btn.config(command=lambda f=func, b=btn, n=name: run_algo(f, b, n))

    # HOVER (chuột vào)
    btn.bind("<Enter>", lambda e, b=btn: b.config(bg="#3fa34d"))

    # RỜI CHUỘT
    btn.bind("<Leave>", lambda e, b=btn: b.config(
        bg="#2d2d2d") if b != active_button else None)

    btn.pack(fill="x", padx=15, pady=5)
    
def run_algo(func, btn, name):

    global active_button

    # reset button cũ
    if active_button:
        active_button.config(bg="#2d2d2d")

    # set button mới
    btn.config(bg="#4caf50")
    active_button = btn

    # 👇 TRUYỀN THÊM name vào bfs_2.py
    func(center_frame, log_text, result_text, name)

    # đóng menu
    toggle_menu()

# =========================================================
# WELCOME
# =========================================================

welcome = tk.Label(
    center_frame,
    text="CHỌN THUẬT TOÁN ☰",
    bg="#1e1e1e",
    fg="white",
    font=("Segoe UI", 24, "bold")
)
welcome.pack(expand=True)

# =========================================================
# RUN
# =========================================================

root.mainloop()