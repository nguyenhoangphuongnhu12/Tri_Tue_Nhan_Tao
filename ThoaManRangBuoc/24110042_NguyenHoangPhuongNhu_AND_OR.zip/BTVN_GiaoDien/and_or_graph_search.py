# https://github.com/nguyenhoangphuongnhu12/Tri_Tue_Nhan_Tao
# Nguyễn Hoàng Phương Như - 24110042
# THUẬT TOÁN AND OR GRAPH SEARCH
import tkinter as tk

class VacuumState:
    def __init__(self, agent_pos, dirty_cells, name=""):
        """
        agent_pos: (row, col)
        dirty_cells: tập hợp chứa tọa độ các ô bẩn
        name: tên nhãn của trạng thái (A, B, C... Z, A1, B1...)
        """
        self.agent_pos = agent_pos
        
        # Logic vừa đi vừa dọn
        dirty_set = set(dirty_cells)
        if agent_pos in dirty_set:
            dirty_set.remove(agent_pos)
            
        self.dirty_cells = tuple(sorted(list(dirty_set)))
        self.name = name

    def is_goal(self):
        return len(self.dirty_cells) == 0

    def __eq__(self, other):
        if not isinstance(other, VacuumState):
            return False
        return self.agent_pos == other.agent_pos and self.dirty_cells == other.dirty_cells

    def __hash__(self):
        return hash((self.agent_pos, self.dirty_cells))

    def get_matrix_string(self):
        """Hàm vẽ ma trận 3x3 dưới dạng chuỗi văn bản trực quan"""
        matrix_lines = []
        for r in range(3):
            row_str = []
            for c in range(3):
                if (r, c) == self.agent_pos:
                    row_str.append(" R ") 
                elif (r, c) in self.dirty_cells:
                    row_str.append(" 1 ") 
                else:
                    row_str.append(" 0 ") 
            matrix_lines.append("[" + "".join(row_str) + "]")
        return "\n".join(matrix_lines)

    def __repr__(self):
        return f"Nút {self.name} (Robot ở {self.agent_pos}):\n{self.get_matrix_string()}"


def generate_node_name(counter_value):
    """Hàm sinh tên tự động theo thứ tự bảng chữ cái A, B, ... Z, A1, B1, ..."""
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    index = counter_value % 26
    cycle = counter_value // 26
    char = alphabet[index]
    return char if cycle == 0 else f"{char}{cycle}"


def get_results(state, action, node_counter):
    """MÔ PHỎNG MÔI TRƯỜNG KHÔNG XÁC ĐỊNH"""
    r, c = state.agent_pos
    results = []
    
    current_dirty = set(state.dirty_cells)
    if (r, c) in current_dirty:
        current_dirty.remove((r, c))
    
    move_offsets = {'UP': (-1, 0), 'DOWN': (1, 0), 'LEFT': (0, -1), 'RIGHT': (0, 1)}
    dr, dc = move_offsets[action]
    
    # 1. TÌNH HUỐNG MONG MUỐN
    nr, nc = r + dr, c + dc
    name_new = generate_node_name(node_counter[0])
    node_counter[0] += 1
    
    dirty_for_new = set(current_dirty)
    if (nr, nc) in dirty_for_new:
        dirty_for_new.remove((nr, nc))
    results.append(VacuumState((nr, nc), dirty_for_new, name=name_new))

    # 2. TÌNH HUỐNG TRƯỢT CHÂN
    if action in ['LEFT', 'RIGHT']:
        sr, sc = r + 1, c 
        if 0 <= sr < 3 and 0 <= sc < 3:
            name_slip = generate_node_name(node_counter[0])
            node_counter[0] += 1
            dirty_for_slip = set(current_dirty)
            if (sr, sc) in dirty_for_slip:
                dirty_for_slip.remove((sr, sc))
            results.append(VacuumState((sr, sc), dirty_for_slip, name=name_slip))
        else:
            results.append(VacuumState((r, c), current_dirty, name=state.name))
            
    elif action in ['UP', 'DOWN']:
        sr, sc = r, c + 1 
        if 0 <= sr < 3 and 0 <= sc < 3:
            name_slip = generate_node_name(node_counter[0])
            node_counter[0] += 1
            dirty_for_slip = set(current_dirty)
            if (sr, sc) in dirty_for_slip:
                dirty_for_slip.remove((sr, sc))
            results.append(VacuumState((sr, sc), dirty_for_slip, name=name_slip))
        else:
            results.append(VacuumState((r, c), current_dirty, name=state.name))

    unique_results = []
    seen = set()
    for s in results:
        identity = (s.agent_pos, s.dirty_cells)
        if identity not in seen:
            seen.add(identity)
            unique_results.append(s)
    return unique_results


# --- THUẬT TOÁN AND-OR GRAPH SEARCH

def and_or_graph_search(start_pos, initial_dirty, rows, cols):
    steps_log = []
    node_counter = [0]
    search_history_snapshots = []
    
    initial_name = generate_node_name(node_counter[0])
    node_counter[0] += 1
    initial_state = VacuumState(start_pos, initial_dirty, name=initial_name)
    steps_log.append(f"=== BẮT ĐẦU TÌM KIẾM ===\n{initial_state}")
    
    class Problem:
        def __init__(self):
            self.initial_state = initial_state
        def actions(self, state):
            r, c = state.agent_pos
            possible_actions = []
            if r > 0: possible_actions.append('UP')
            if r < 2: possible_actions.append('DOWN')
            if c > 0: possible_actions.append('LEFT')
            if c < 2: possible_actions.append('RIGHT')
            return possible_actions
        def results(self, state, action):
            return get_results(state, action, node_counter)

    problem = Problem()
    
    def or_search_inner(state, path):
        current_run_path = path + [state]
        # Mỗi snapshot lưu kèm theo chuỗi ghi chú trạng thái hiện tại của nút đó
        note = "FORWARD"
        if state.is_goal():
            note = "GOAL_REACHED"
        elif state in path:
            note = "DUPLICATE"
            
        search_history_snapshots.append((list(current_run_path), note))
        
        if state.is_goal():
            steps_log.append(f"[ĐỈNH OR] {state.name} ĐÃ SẠCH BONG! Thành công.")
            return "Goal_Reached"
        if state in path:
            steps_log.append(f"[ĐỈNH OR] {state.name} bị trùng lặp đường cũ! Nhánh lỗi.")
            return "failure"
            
        valid_actions = problem.actions(state)
        steps_log.append(f"[ĐỈNH OR] Xét nút {state.name}. Hướng đi hợp lệ có thể thử: {valid_actions}\n{state}")
        
        for action in valid_actions:
            result_states = problem.results(state, action)
            situations = ", ".join([s.name for s in result_states])
            steps_log.append(f"Thử hành động [{action}] ➔ Xuống [ĐỈNH AND] xét tập kết quả: [{situations}]")
            
            plan = and_search_inner(result_states, current_run_path, situations)
            
            if plan != "failure":
                steps_log.append(f"[ĐỈNH OR] Nút {state.name} CHỌN hành động [{action}]!")
                return {action: plan}
            else:
                steps_log.append(f"[QUAY LUI] Nhánh hành động [{action}] bế tắc! Quay trở lại nút cha: {state.name}")
                # Khi quay lui, lưu note đặc biệt báo hiệu hủy nhánh hành động
                search_history_snapshots.append((list(current_run_path), f"BACKTRACK_{action}_{situations}"))
                
        steps_log.append(f"[ĐỈNH OR - THẤT BẠI] Nút {state.name} không còn hướng đi nào giải quyết được đỉnh AND.")
        return "failure"

    def and_search_inner(states, path, and_group_name):
        node_names = ", ".join([s.name for s in states])
        steps_log.append(f"[ĐỈNH AND] Bắt buộc giải quyết TẤT CẢ các trạng thái: [{node_names}]")
        plans = {}
        for s in states:
            steps_log.append(f"Xét nhánh ngẫu nhiên: {s.name}")
            plan_s = or_search_inner(s, path)
            if plan_s == "failure":
                steps_log.append(f"Nhánh {s.name} thất bại! Khiến [ĐỈNH AND] chứa [{node_names}] thất bại.")
                return "failure"
            plans[s] = plan_s
        steps_log.append(f"[ĐỈNH AND] Tập kết quả [{node_names}] giải quyết xong!")
        return plans

    plan = or_search_inner(problem.initial_state, [])
    
    flat_path = []
    if plan and plan != "failure":
        def extract_path(state, current_plan):
            flat_path.append(state)
            if current_plan == "Goal_Reached" or not isinstance(current_plan, dict):
                return
            for action, sub_plan in current_plan.items():
                if isinstance(sub_plan, dict):
                    for next_state, next_sub in sub_plan.items():
                        extract_path(next_state, next_sub)
                        break
                break
        extract_path(problem.initial_state, plan)
        steps_log.append("[THÀNH CÔNG] Robot đã tìm ra chiến lược dọn sạch mọi ngóc ngách!")
        return flat_path, steps_log, False
    else:
        steps_log.append("[THẤT BẠI] Không tìm ra cách di chuyển an toàn tuyệt đối trước môi trường trượt chân.")
        return search_history_snapshots, steps_log, True

# =========================================================
# HÀM RUN CHÍNH (GIAO DIỆN TKINTER)
# =========================================================
def run(center_frame, log_text, result_text, name):
    ROWS, COLS = 3, 3  
    start_pos = (0, 0) 
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_frame.configure(bg="#ffffff")
    for widget in center_frame.winfo_children():
        widget.destroy()

    title_label = tk.Label(center_frame, text="VACUUM WORLD - AND OR GRAPH SEARCH", bg="#1a1a1a", fg="#00ffcc", font=("Segoe UI", 20, "bold"), pady=8)
    title_label.pack(side="top", fill="x", pady=(10, 5))

    status_msg_label = tk.Label(center_frame, text="🤖 ĐANG KHỞI TẠO HÀNH TRÌNH...", bg="#ffffff", fg="#1a1a1a", font=("Segoe UI", 12, "bold"), wraplength=700, justify="center")
    status_msg_label.pack(side="top", pady=(5, 5))

    legend_bar = tk.Frame(center_frame, bg="#1a1a1a", pady=6)
    legend_bar.pack(side="top", fill="x", padx=40, pady=(0, 15))
    center_legend = tk.Frame(legend_bar, bg="#1a1a1a")
    center_legend.pack(anchor="center")
    tk.Label(center_legend, bg="#e0e0e0", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 5))
    tk.Label(center_legend, text="0 = CLEAN CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
    tk.Label(center_legend, bg="#ff6666", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="1 = DIRTY CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
    tk.Label(center_legend, bg="#3399ff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="BLUE = ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    container = tk.Frame(center_frame, bg="#ffffff")
    container.pack(expand=True)
    CELL_SIZE = 100
    canvas = tk.Canvas(container, width=COLS * CELL_SIZE, height=ROWS * CELL_SIZE, bg="#ffffff", highlightthickness=0)
    canvas.pack(side="bottom")

    search_data, steps_log, check_failed = and_or_graph_search(start_pos, initial_dirty, ROWS, COLS)
    
    log_text.delete("1.0", tk.END)
    for log_block in steps_log:
        log_text.insert(tk.END, log_block + "\n\n")
    log_text.see(tk.END) 
    log_text.update_idletasks()

    result_text.delete("1.0", tk.END)
    if not search_data or len(search_data) == 0:
        result_text.insert(tk.END, "Kết quả: KHÔNG TÌM THẤY ĐƯỜNG ĐI!")
        return

    if not check_failed:
        final_path = search_data
        path_names = [node.name for node in final_path]
        path_coords = [str(node.agent_pos) for node in final_path]
        result_text.insert(tk.END, "=== FINAL SOLUTION ===\n\n")
        result_text.insert(tk.END, f"Lộ trình các nút:\n{' -> '.join(path_names)}\n\n")
        result_text.insert(tk.END, f"Tọa độ di chuyển:\n{' -> '.join(path_coords)}\n\n")
        result_text.insert(tk.END, "TRẠNG THÁI: THÀNH CÔNG (Đã dọn sạch)!")
    else:
        final_path = search_data[-1][0] # Lấy mảng path từ snapshot cuối
        result_text.insert(tk.END, "=== NO SOLUTION FOUND ===\n\n")
        result_text.insert(tk.END, "TRẠNG THÁI: BỊ KẸT (Thuật toán thất bại toàn bộ các nhánh)!")

    def draw_current_frame(current_path_nodes, note_type="FORWARD"):
        canvas.delete("all")
        if not current_path_nodes:
            return
        
        active_node = current_path_nodes[-1]
        
        # LOGIC HIỂN THỊ CHỮ THEO DÕI NHÁNH AND/OR THÔNG MINH
        if note_type == "GOAL_REACHED":
            status_msg_label.config(text=f"[ĐỈNH OR] Nút {active_node.name} ĐÃ ĐƯỢC DỌN SẠCH! (Đang xét các nút khác cùng cấp)...", fg="#009933")
        elif note_type == "DUPLICATE":
            status_msg_label.config(text=f"[ĐỈNH OR] Nút {active_node.name} bị trùng lặp đường cũ ➔ Nhánh này kẹt bế tắc!", fg="#cc0000")
        elif note_type.startswith("BACKTRACK_"):
            # Tách chuỗi note để lấy thông tin hành động và tập đỉnh AND bị sập
            _, action, situations = note_type.split("_")
            status_msg_label.config(text=f"[QUAY LUI] Nhánh hành động [{action}] bế tắc do lỗi từ tập đỉnh AND [{situations}]!\nQuay trở lại nút cha: {active_node.name}", fg="#ff6600")
        else:
            status_msg_label.config(text=f"[TIẾN THỬ NGHIỆM] Đang lướt qua nút: {active_node.name}", fg="#0066cc")

        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                is_dirty = (r, c) in active_node.dirty_cells
                
                if (r, c) == active_node.agent_pos:
                    cell_bg, text_color, width_border = "#3399ff", "white", 3
                else:
                    cell_bg, text_color, width_border = ("#ff6666", "white", 1) if is_dirty else ("#e0e0e0", "#444444", 1)
                    
                canvas.create_rectangle(x1, y1, x2, y2, fill=cell_bg, outline="white", width=width_border)
                canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2, text="1" if is_dirty else "0", fill=text_color, font=("Consolas", 20, "bold"))
                
                if (r, c) == active_node.agent_pos:
                    canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2 + 18, text="ROBOT", fill="white", font=("Segoe UI", 10, "bold"))
                    
        if len(current_path_nodes) > 1:
            for i in range(len(current_path_nodes) - 1):
                r1, c1 = current_path_nodes[i].agent_pos
                r2, c2 = current_path_nodes[i+1].agent_pos
                canvas.create_line(c1*CELL_SIZE + CELL_SIZE/2, r1*CELL_SIZE + CELL_SIZE/2, c2*CELL_SIZE + CELL_SIZE/2, r2*CELL_SIZE + CELL_SIZE/2, fill="#0022cc", width=4, arrow=tk.LAST)

    def animate(step_index):
        if not check_failed:
            if step_index < len(final_path):
                draw_current_frame(final_path[:step_index + 1], "FORWARD")
                center_frame.after(700, lambda: animate(step_index + 1))
            else:
                status_msg_label.config(text="HOÀN THÀNH: TÌM KIẾM CHIẾN LƯỢC THÀNH CÔNG!", fg="#009933")
        else:
            if step_index < len(search_data):
                current_snapshot, note_type = search_data[step_index]
                
                # Điều chỉnh thời gian đứng hình lâu hơn khi dọn sạch hoặc quay lui để người xem kịp đọc chữ
                if note_type == "GOAL_REACHED" or note_type.startswith("BACKTRACK_") or note_type == "DUPLICATE":
                    delay = 1500 
                else:
                    delay = 700
                    
                draw_current_frame(current_snapshot, note_type)
                center_frame.after(delay, lambda: animate(step_index + 1))
            else:
                status_msg_label.config(text="KẾT THÚC: ROBOT BỊ KẸT (HOÀN TOÀN THẤT BẠI)!", fg="#cc0000")
                
    animate(0)