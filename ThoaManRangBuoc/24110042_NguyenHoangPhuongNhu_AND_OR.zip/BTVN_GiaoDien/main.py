import tkinter as tk
from tkinter.scrolledtext import ScrolledText
import os
import importlib
# =========================================================
# LOAD ALGORITHMS
# =========================================================
algorithms = {}
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

for file in os.listdir(BASE_DIR):
    if file.endswith(".py") and file != "main.py":
        name = file[:-3]
        try:
            module = importlib.import_module(name)
            importlib.reload(module)
            if hasattr(module, "run"):
                display_name = name.replace("_", " ").upper()
                algorithms[display_name] = module.run
        except Exception as e:
            print(f"Lỗi load {name}: {e}")

# =========================================================
# WINDOW & CONTAINERS
# =========================================================
root = tk.Tk()
root.title("AI Algorithm Visualizer")
root.geometry("1400x800")
root.configure(bg="#121212")

MENU_WIDTH = 240
active_button = None
menu_visible = False

top_bar = tk.Frame(root, bg="#1f1f1f", height=50)
top_bar.pack(side="top", fill="x")

main_container = tk.Frame(root, bg="#121212")
main_container.pack(fill="both", expand=True)

center_frame = tk.Frame(main_container, bg="#1e1e1e")
center_frame.pack(side="left", fill="both", expand=True, padx=10, pady=10)

log_frame = tk.Frame(main_container, bg="#1a1a1a", width=350)
log_frame.pack(side="right", fill="y", padx=(0,10), pady=10)

log_text = ScrolledText(log_frame, bg="#111111", fg="#00ffcc", font=("Consolas", 11), relief="flat")
log_text.pack(fill="both", expand=True, padx=10, pady=(0,10))

bottom_frame = tk.Frame(root, bg="#0f0f0f", height=120)
bottom_frame.pack(side="bottom", fill="x")

result_text = tk.Text(bottom_frame, height=4, bg="#111111", fg="white", font=("Consolas", 12), relief="flat")
result_text.pack(fill="x", padx=15, pady=(0,10))

# =========================================================
# SIDE MENU (CẤU TRÚC CUỘN ỔN ĐỊNH)
# =========================================================
menu_canvas = tk.Canvas(root, bg="#202020", width=MENU_WIDTH, highlightthickness=0)
menu_canvas.place(x=-MENU_WIDTH, y=50, relheight=1)

menu_scrollbar = tk.Scrollbar(root, orient="vertical", command=menu_canvas.yview)
menu_scrollbar.place(x=-15, y=50, relheight=1)

menu_canvas.configure(yscrollcommand=menu_scrollbar.set)

side_menu = tk.Frame(menu_canvas, bg="#202020", width=MENU_WIDTH)
menu_canvas.create_window((0, 0), window=side_menu, anchor="nw")

def _on_mousewheel(event):
    menu_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

menu_canvas.bind("<Enter>", lambda e: menu_canvas.bind_all("<MouseWheel>", _on_mousewheel))
menu_canvas.bind("<Leave>", lambda e: menu_canvas.unbind_all("<MouseWheel>"))

# =========================================================
# HÀM HỖ TRỢ MENU & RUN
# =========================================================
def toggle_menu():
    global menu_visible
    # Cập nhật scrollregion ngay tại đây để chắc chắn cuộn được ngay khi mở
    side_menu.update_idletasks()
    menu_canvas.configure(scrollregion=menu_canvas.bbox("all"))
    
    target_x = 0 if not menu_visible else -MENU_WIDTH
    scroll_x = MENU_WIDTH - 15 if not menu_visible else -15
    menu_canvas.place(x=target_x, y=50)
    menu_scrollbar.place(x=scroll_x, y=50)
    menu_visible = not menu_visible

def run_algo(func, btn, name):
    global active_button
    
    # 📌 CƠ CHẾ AN TOÀN: Quét tìm Canvas hiện tại để ép dừng tiến trình animation 
    # trước khi phá hủy (destroy) các widget con, tránh lỗi "bad window path name"
    for widget in center_frame.winfo_children():
        if isinstance(widget, tk.Canvas) and hasattr(widget, 'anim_id') and widget.anim_id:
            try:
                center_frame.after_cancel(widget.anim_id)
            except Exception:
                pass
                
    # Vẫn giữ vòng lặp dọn dẹp hệ thống tổng quát (đã được bọc try-except tránh crash)
    try:
        for after_id in root.tk.call('after', 'info'):
            root.after_cancel(after_id)
    except Exception:
        pass
    
    if active_button: 
        active_button.config(bg="#2d2d2d")
    btn.config(bg="#4caf50")
    active_button = btn
    
    # Dọn dẹp giao diện cũ và xóa văn bản log
    for widget in center_frame.winfo_children(): 
        widget.destroy()
        
    log_text.delete("1.0", tk.END)
    result_text.delete("1.0", tk.END)
    
    # Khởi chạy thuật toán mới
    func(center_frame, log_text, result_text, name)
    toggle_menu()

# =========================================================
# TẠO NÚT BẤM
# =========================================================
tk.Label(side_menu, text="THUẬT TOÁN", bg="#202020", fg="white", font=("Segoe UI", 16, "bold")).pack(pady=20)
for name, func in algorithms.items():
    btn = tk.Button(side_menu, text=name, bg="#2d2d2d", fg="white", relief="flat", font=("Segoe UI", 12), pady=10)
    btn.config(command=lambda f=func, b=btn, n=name: run_algo(f, b, n))
    btn.bind("<Enter>", lambda e, b=btn: b.config(bg="#3fa34d"))
    btn.bind("<Leave>", lambda e, b=btn: b.config(bg="#2d2d2d") if b != active_button else None)
    btn.pack(fill="x", padx=15, pady=5)

menu_btn = tk.Button(top_bar, text="☰", font=("Segoe UI", 18), bg="#1f1f1f", fg="white", bd=0, command=toggle_menu)
menu_btn.pack(side="left", padx=15)

tk.Label(center_frame, text="CHỌN THUẬT TOÁN ☰", bg="#1e1e1e", fg="white", font=("Segoe UI", 24, "bold")).pack(expand=True)

root.mainloop()