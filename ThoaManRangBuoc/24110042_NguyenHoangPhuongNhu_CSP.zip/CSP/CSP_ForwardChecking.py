# https://github.com/nguyenhoangphuongnhu12/Tri_Tue_Nhan_Tao
# Nguyễn Hoàng Phương Như - 24110042
# THUẬT TOÁN CSP FORWARD CHECKING
import tkinter as tk
from tkinter import scrolledtext
import copy

# =========================================================
# LỚP THUẬT TOÁN CSP FORWARD CHECKING
# =========================================================
class MapColoringCSP:
    def __init__(self, regions, neighbors, colors):
        self.regions = regions
        self.neighbors = neighbors
        self.colors = colors
        self.assignment = {}
        # Khởi tạo miền giá trị (Domains) ban đầu cho mỗi vùng
        self.domains = {r: list(colors) for r in regions}

    def forward_check(self, region, color, domains):
        """ Loại bỏ màu vừa gán khỏi domain của các vùng kề """
        for neighbor in self.neighbors.get(region, []):
            if neighbor not in self.assignment and color in domains[neighbor]:
                domains[neighbor].remove(color)
                if not domains[neighbor]: return False # Bế tắc
        return True

    def backtracking_search(self, step_callback=None):
        return self._backtrack(step_callback)

    def _backtrack(self, step_callback):
        if len(self.assignment) == len(self.regions):
            return self.assignment

        unassigned = [r for r in self.regions if r not in self.assignment]
        region = unassigned[0]

        for color in self.domains[region]:
            if step_callback: step_callback(region, color, "TRY", None)
            
            # Lưu trạng thái domains
            old_domains = copy.deepcopy(self.domains)
            self.assignment[region] = color
            
            if self.forward_check(region, color, self.domains):
                if step_callback: step_callback(region, color, "ADVANCE", None)
                result = self._backtrack(step_callback)
                if result is not None: return result
            else:
                conflicting = [n for n in self.neighbors.get(region, []) if n not in self.assignment and color in old_domains[n]]
                if step_callback: step_callback(region, color, "CONFLICT", conflicting)

            # Quay lui
            del self.assignment[region]
            self.domains = old_domains
            if step_callback: step_callback(region, color, "BACKTRACK", None)
        return None

# =========================================================
# DỮ LIỆU BẢN ĐỒ
# =========================================================
REGION_POLYGONS = {
    "Phường 1 (Hiệp Bình)": [150, 300, 250, 300, 270, 420, 160, 420],
    "Phường 2 (Tam Bình)": [150, 180, 280, 180, 250, 300, 150, 300],
    "Phường 3 (Thủ Đức)": [250, 300, 380, 300, 380, 420, 270, 420],
    "Phường 4 (Linh Xuân)": [280, 180, 420, 180, 380, 300, 250, 300],
    "Phường 5 (Long Bình)": [420, 180, 600, 180, 550, 320, 380, 300],
    "Phường 6 (Tăng Nhơn Phú)": [380, 300, 550, 320, 500, 450, 380, 420],
    "Phường 7 (Phước Long)": [380, 420, 500, 450, 450, 550, 340, 520],
    "Phường 8 (Long Phước)": [550, 320, 680, 350, 650, 520, 500, 450],
    "Phường 9 (Long Trường)": [500, 450, 650, 520, 580, 650, 450, 550],
    "Phường 10 (An Khánh)": [160, 420, 270, 420, 250, 560, 150, 520],
    "Phường 11 (Bình Trưng)": [270, 420, 380, 420, 340, 520, 250, 560],
    "Phường 12 (Cát Lái)": [250, 560, 340, 520, 450, 550, 380, 680]
}

LABEL_COORDS = {
    "Phường 1 (Hiệp Bình)": (205, 360, "①"), "Phường 2 (Tam Bình)": (215, 240, "②"),
    "Phường 3 (Thủ Đức)": (320, 360, "③"), "Phường 4 (Linh Xuân)": (330, 240, "④"),
    "Phường 5 (Long Bình)": (485, 240, "⑤"), "Phường 6 (Tăng Nhơn Phú)": (450, 365, "⑥"),
    "Phường 7 (Phước Long)": (415, 470, "⑦"), "Phường 8 (Long Phước)": (595, 420, "⑧"),
    "Phường 9 (Long Trường)": (545, 540, "⑨"), "Phường 10 (An Khánh)": (205, 480, "⑩"),
    "Phường 11 (Bình Trưng)": (310, 480, "⑪"), "Phường 12 (Cát Lái)": (355, 600, "⑫")
}

NEIGHBORS = {
    "Phường 1 (Hiệp Bình)": ["Phường 2 (Tam Bình)", "Phường 3 (Thủ Đức)", "Phường 10 (An Khánh)"],
    "Phường 2 (Tam Bình)": ["Phường 1 (Hiệp Bình)", "Phường 4 (Linh Xuân)"],
    "Phường 3 (Thủ Đức)": ["Phường 1 (Hiệp Bình)", "Phường 4 (Linh Xuân)", "Phường 6 (Tăng Nhơn Phú)", "Phường 7 (Phước Long)", "Phường 11 (Bình Trưng)"],
    "Phường 4 (Linh Xuân)": ["Phường 2 (Tam Bình)", "Phường 3 (Thủ Đức)", "Phường 6 (Tăng Nhơn Phú)", "Phường 5 (Long Bình)"],
    "Phường 5 (Long Bình)": ["Phường 4 (Linh Xuân)", "Phường 6 (Tăng Nhơn Phú)", "Phường 8 (Long Phước)"],
    "Phường 6 (Tăng Nhơn Phú)": ["Phường 4 (Linh Xuân)", "Phường 5 (Long Bình)", "Phường 3 (Thủ Đức)", "Phường 7 (Phước Long)", "Phường 8 (Long Phước)", "Phường 9 (Long Trường)"],
    "Phường 7 (Phước Long)": ["Phường 3 (Thủ Đức)", "Phường 6 (Tăng Nhơn Phú)", "Phường 9 (Long Trường)", "Phường 11 (Bình Trưng)", "Phường 12 (Cát Lái)"],
    "Phường 8 (Long Phước)": ["Phường 5 (Long Bình)", "Phường 6 (Tăng Nhơn Phú)", "Phường 9 (Long Trường)"],
    "Phường 9 (Long Trường)": ["Phường 6 (Tăng Nhơn Phú)", "Phường 7 (Phước Long)", "Phường 8 (Long Phước)", "Phường 11 (Bình Trưng)", "Phường 12 (Cát Lái)"],
    "Phường 10 (An Khánh)": ["Phường 1 (Hiệp Bình)", "Phường 11 (Bình Trưng)", "Phường 12 (Cát Lái)"],
    "Phường 11 (Bình Trưng)": ["Phường 3 (Thủ Đức)", "Phường 7 (Phước Long)", "Phường 9 (Long Trường)", "Phường 10 (An Khánh)", "Phường 12 (Cát Lái)"],
    "Phường 12 (Cát Lái)": ["Phường 10 (An Khánh)", "Phường 11 (Bình Trưng)", "Phường 9 (Long Trường)", "Phường 7 (Phước Long)"]
}

COLOR_MAP = {"Đỏ": "#ff6666", "Xanh lá": "#4bd24b", "Xanh dương": "#4696ff", "Vàng": "#ffeb46"}
COLORS = list(COLOR_MAP.keys())

# =========================================================
# GIAO DIỆN CHÍNH
# =========================================================
def main():
    root = tk.Tk()
    root.title("MAP COLORING - FORWARD CHECKING")
    root.geometry("1450x950")
    root.configure(bg="#1e1e1e")

    # Layout chính
    top_frame = tk.Frame(root, bg="#1e1e1e")
    top_frame.pack(side="top", fill="both", expand=True)
    
    left_frame = tk.Frame(top_frame, bg="#121212", bd=1, relief="solid")
    left_frame.pack(side="left", padx=10, pady=10, fill="both", expand=True)
    
    right_frame = tk.Frame(top_frame, bg="#1e1e1e")
    right_frame.pack(side="right", padx=10, pady=10, fill="y")

    canvas = tk.Canvas(left_frame, width=800, height=750, bg="#1a1a1a")
    canvas.pack(pady=5)
    canvas.create_text(400, 30, text="CSP - FORWARD CHECKING", font=("Segoe UI", 16, "bold"), fill="#ffcc00")
    
    tk.Label(right_frame, text="TIẾN TRÌNH THUẬT TOÁN", font=("Segoe UI", 11, "bold"), bg="#1e1e1e", fg="#00ffcc").pack(anchor="w")
    log_text = scrolledtext.ScrolledText(right_frame, width=65, height=40, font=("Consolas", 10), bg="#000", fg="#fff")
    log_text.pack(pady=(0, 10))

    bottom_frame = tk.Frame(root, bg="#1e1e1e")
    bottom_frame.pack(side="bottom", fill="x", padx=10, pady=10)
    tk.Label(bottom_frame, text="KẾT QUẢ CUỐI CÙNG", font=("Segoe UI", 11, "bold"), bg="#1e1e1e", fg="#00ffcc").pack(anchor="w")
    result_text = scrolledtext.ScrolledText(bottom_frame, height=8, font=("Consolas", 11), bg="#000", fg="#00ffcc")
    result_text.pack(fill="x")

    # Vẽ bản đồ
    all_x = [pts[i] for pts in REGION_POLYGONS.values() for i in range(0, len(pts), 2)]
    all_y = [pts[i] for pts in REGION_POLYGONS.values() for i in range(1, len(pts), 2)]
    DX, DY = 400 - (sum(all_x)/len(all_x)), 300 - (sum(all_y)/len(all_y))
    poly_ids = {r: canvas.create_polygon([p[i] + (DX if i%2==0 else DY) for i in range(len(p))], fill="#e0e0e0", outline="white") for r, p in REGION_POLYGONS.items()}
    for r, (lx, ly, t) in LABEL_COORDS.items(): canvas.create_text(lx+DX, ly+DY, text=t, font=("Arial", 14, "bold"))

    csp = MapColoringCSP(list(REGION_POLYGONS.keys()), NEIGHBORS, COLORS)
    history = []

    def collect(r, c, t, e):
        history.append((r, c, t))
        sep = "-" * 40 + "\n"
        if t == "TRY":
            log_text.insert("end", f"{sep}THỬ: {r} với màu [{c}]\n")
            log_text.insert("end", f"Domain hiện tại của {r}: {csp.domains[r]}\n")
        
        elif t == "ADVANCE":
            log_text.insert("end", f"Hợp lệ! Đã xóa màu [{c}] khỏi domain các vùng kề:\n")
            # Hiển thị domain sau khi forward checking
            for neighbor in NEIGHBORS.get(r, []):
                if neighbor not in csp.assignment:
                    log_text.insert("end", f"   - {neighbor}: {csp.domains[neighbor]}\n")
        
        elif t == "CONFLICT":
            log_text.insert("end", f"XUNG ĐỘT: {', '.join(e)} bị rỗng domain!\n")
            
        elif t == "BACKTRACK":
            log_text.insert("end", "QUAY LUI: Khôi phục lại domain ban đầu.\n")
            
        log_text.see("end")
        
    final = csp.backtracking_search(step_callback=collect)
    if final: result_text.insert("end", str(final))

    def animate(i):
        if i < len(history):
            r, c, t = history[i]
            if t == "ADVANCE": canvas.itemconfig(poly_ids[r], fill=COLOR_MAP[c])
            elif t == "BACKTRACK": canvas.itemconfig(poly_ids[r], fill="#e0e0e0")
            root.after(200, lambda: animate(i + 1))
    root.after(500, lambda: animate(0))
    root.mainloop()

if __name__ == "__main__": main()