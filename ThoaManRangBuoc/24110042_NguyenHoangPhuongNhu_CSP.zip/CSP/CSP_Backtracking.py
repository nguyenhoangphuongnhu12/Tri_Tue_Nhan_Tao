# https://github.com/nguyenhoangphuongnhu12/Tri_Tue_Nhan_Tao
# Nguyễn Hoàng Phương Như - 24110042
# THUẬT TOÁN CSP - BACKTRACKING
import tkinter as tk
from tkinter import scrolledtext

# =========================================================
# LỚP THUẬT TOÁN CSP BACKTRACKING
# =========================================================
class MapColoringCSP:
    def __init__(self, regions, neighbors, colors):
        self.regions = regions
        self.neighbors = neighbors
        self.colors = colors
        self.assignment = {}

    def is_consistent(self, region, color):
        for neighbor in self.neighbors.get(region, []):
            if neighbor in self.assignment and self.assignment[neighbor] == color:
                return False
        return True

    def backtracking_search(self, step_callback=None):
        return self._backtrack(step_callback)

    def _backtrack(self, step_callback):
        if len(self.assignment) == len(self.regions):
            return self.assignment

        unassigned = [r for r in self.regions if r not in self.assignment]
        region = unassigned[0]

        for color in self.colors:
            if step_callback:
                step_callback(region, color, "TRY")

            if self.is_consistent(region, color):
                self.assignment[region] = color
                if step_callback:
                    step_callback(region, color, "ADVANCE")

                result = self._backtrack(step_callback)
                if result is not None:
                    return result

                del self.assignment[region]
                if step_callback:
                    step_callback(region, color, "BACKTRACK")
            else:
                conflicting_neighbors = [
                    n for n in self.neighbors.get(region, [])
                    if n in self.assignment and self.assignment[n] == color
                ]
                if step_callback:
                    step_callback(region, color, "CONFLICT", conflicting_neighbors)
                    
        return None

# =========================================================
# DỮ LIỆU BẢN ĐỒ
# =========================================================
REGION_POLYGONS = {
    "Phường 1 (Hiệp Bình)": [150, 300, 250, 300, 270, 420, 160, 420],
    "Phường 2 (Tam Bình)": [150, 180, 280, 180, 250, 300, 150, 300],
    "Phường 3 (Thủ Đức)": [250, 300, 380, 300, 380, 420, 270, 420],
    "Phường 4 (Linh Xuân)": [280, 180, 420, 180, 380, 300, 250, 300],
    "Phường 5 (Long Bình)": [420, 180, 600, 180, 550, 320, 380, 300],
    "Phường 6 (Tăng Nhơn Phú)": [380, 300, 550, 320, 500, 450, 380, 420],
    "Phường 7 (Phước Long)": [380, 420, 500, 450, 450, 550, 340, 520],
    "Phường 8 (Long Phước)": [550, 320, 680, 350, 650, 520, 500, 450],
    "Phường 9 (Long Trường)": [500, 450, 650, 520, 580, 650, 450, 550],
    "Phường 10 (An Khánh)": [160, 420, 270, 420, 250, 560, 150, 520],
    "Phường 11 (Bình Trưng)": [270, 420, 380, 420, 340, 520, 250, 560],
    "Phường 12 (Cát Lái)": [250, 560, 340, 520, 450, 550, 380, 680]
}

LABEL_COORDS = {
    "Phường 1 (Hiệp Bình)": (205, 360, "①"),
    "Phường 2 (Tam Bình)": (215, 240, "②"),
    "Phường 3 (Thủ Đức)": (320, 360, "③"),
    "Phường 4 (Linh Xuân)": (330, 240, "④"),
    "Phường 5 (Long Bình)": (485, 240, "⑤"),
    "Phường 6 (Tăng Nhơn Phú)": (450, 365, "⑥"),
    "Phường 7 (Phước Long)": (415, 470, "⑦"),
    "Phường 8 (Long Phước)": (595, 420, "⑧"),
    "Phường 9 (Long Trường)": (545, 540, "⑨"),
    "Phường 10 (An Khánh)": (205, 480, "⑩"),
    "Phường 11 (Bình Trưng)": (310, 480, "⑪"),
    "Phường 12 (Cát Lái)": (355, 600, "⑫")
}

NEIGHBORS = {
    "Phường 1 (Hiệp Bình)": ["Phường 2 (Tam Bình)", "Phường 3 (Thủ Đức)", "Phường 10 (An Khánh)"],
    "Phường 2 (Tam Bình)": ["Phường 1 (Hiệp Bình)", "Phường 4 (Linh Xuân)"],
    "Phường 3 (Thủ Đức)": ["Phường 1 (Hiệp Bình)", "Phường 4 (Linh Xuân)", "Phường 6 (Tăng Nhơn Phú)", "Phường 7 (Phước Long)", "Phường 11 (Bình Trưng)"],
    "Phường 4 (Linh Xuân)": ["Phường 2 (Tam Bình)", "Phường 3 (Thủ Đức)", "Phường 6 (Tăng Nhơn Phú)", "Phường 5 (Long Bình)"],
    "Phường 5 (Long Bình)": ["Phường 4 (Linh Xuân)", "Phường 6 (Tăng Nhơn Phú)", "Phường 8 (Long Phước)"],
    "Phường 6 (Tăng Nhơn Phú)": ["Phường 4 (Linh Xuân)", "Phường 5 (Long Bình)", "Phường 3 (Thủ Đức)", "Phường 7 (Phước Long)", "Phường 8 (Long Phước)", "Phường 9 (Long Trường)"],
    "Phường 7 (Phước Long)": ["Phường 3 (Thủ Đức)", "Phường 6 (Tăng Nhơn Phú)", "Phường 9 (Long Trường)", "Phường 11 (Bình Trưng)", "Phường 12 (Cát Lái)"],
    "Phường 8 (Long Phước)": ["Phường 5 (Long Bình)", "Phường 6 (Tăng Nhơn Phú)", "Phường 9 (Long Trường)"],
    "Phường 9 (Long Trường)": ["Phường 6 (Tăng Nhơn Phú)", "Phường 7 (Phước Long)", "Phường 8 (Long Phước)", "Phường 11 (Bình Trưng)", "Phường 12 (Cát Lái)"],
    "Phường 10 (An Khánh)": ["Phường 1 (Hiệp Bình)", "Phường 11 (Bình Trưng)", "Phường 12 (Cát Lái)"],
    "Phường 11 (Bình Trưng)": ["Phường 3 (Thủ Đức)", "Phường 7 (Phước Long)", "Phường 9 (Long Trường)", "Phường 10 (An Khánh)", "Phường 12 (Cát Lái)"],
    "Phường 12 (Cát Lái)": ["Phường 10 (An Khánh)", "Phường 11 (Bình Trưng)", "Phường 9 (Long Trường)", "Phường 7 (Phước Long)"]
}

COLOR_MAP = {"Đỏ": "#ff6666", "Xanh lá": "#4bd24b", "Xanh dương": "#4696ff", "Vàng": "#ffeb46"}
COLORS = list(COLOR_MAP.keys())

# =========================================================
# GIAO DIỆN CHÍNH
# =========================================================
def main():
    root = tk.Tk()
    root.title("CHƯƠNG TRÌNH TÔ MÀU BẢN ĐỒ CSP HOÀN THIỆN")
    root.geometry("1450x950")
    root.configure(bg="#1e1e1e")

    # --- TỰ ĐỘNG TÍNH TOÁN CĂN GIỮA ---
    all_x = []
    all_y = []
    for points in REGION_POLYGONS.values():
        for i in range(len(points)):
            if i % 2 == 0: all_x.append(points[i])
            else: all_y.append(points[i])
    DX = 400 - (sum(all_x)/len(all_x))
    DY = 300 - (sum(all_y)/len(all_y))

    # Layout chính
    top_frame = tk.Frame(root, bg="#1e1e1e")
    top_frame.pack(side="top", fill="both", expand=True)

    left_frame = tk.Frame(top_frame, bg="#121212", bd=1, relief="solid")
    left_frame.pack(side="left", padx=10, pady=10, fill="both", expand=True)

    right_frame = tk.Frame(top_frame, bg="#1e1e1e")
    right_frame.pack(side="right", padx=10, pady=10, fill="y")

    # Canvas
    canvas = tk.Canvas(left_frame, width=800, height=750, bg="#1a1a1a", highlightthickness=0)
    canvas.pack(pady=5)
    canvas.create_text(400, 30, text="CSP - BACKTRACKING", font=("Segoe UI", 16, "bold"), fill="#ffcc00")

    # Khung Log
    tk.Label(right_frame, text="TIẾN TRÌNH THUẬT TOÁN", font=("Segoe UI", 11, "bold"), bg="#1e1e1e", fg="#00ffcc").pack(anchor="w")
    log_text = scrolledtext.ScrolledText(right_frame, width=65, height=40, font=("Consolas", 10), bg="#000000", fg="#ffffff")
    log_text.pack(pady=(0, 10))

    # Khung Kết quả
    bottom_frame = tk.Frame(root, bg="#1e1e1e")
    bottom_frame.pack(side="bottom", fill="x", padx=10, pady=10)
    tk.Label(bottom_frame, text="KẾT QUẢ CUỐI CÙNG", font=("Segoe UI", 11, "bold"), bg="#1e1e1e", fg="#00ffcc").pack(anchor="w")
    result_text = scrolledtext.ScrolledText(bottom_frame, height=8, font=("Consolas", 11), bg="#000000", fg="#ffffff")
    result_text.pack(fill="x")

    # Vẽ với độ lệch đã tính
    polygon_ids = {}
    for r_name, points in REGION_POLYGONS.items():
        coords = [points[i] + (DX if i % 2 == 0 else DY) for i in range(len(points))]
        polygon_ids[r_name] = canvas.create_polygon(coords, fill="#e0e0e0", outline="#111111", width=2)
        
    for r_name, (lx, ly, ltxt) in LABEL_COORDS.items(): 
        canvas.create_text(lx + DX, ly + DY, text=ltxt, font=("Segoe UI", 14, "bold"), fill="#000000")

    csp = MapColoringCSP(list(REGION_POLYGONS.keys()), NEIGHBORS, COLORS)
    history_steps = []

    def collect_steps(region, color, action_type, extra_info=None):
        history_steps.append((region, color, action_type, extra_info))
        
        if action_type == "TRY": 
            log_text.insert(tk.END, f"\nThử tô màu [{color}] cho vùng: {region}\n")
        elif action_type == "ADVANCE": 
            log_text.insert(tk.END, f"\nHợp lệ! Đã nhận màu [{color}]\n")
        elif action_type == "CONFLICT": 
            # SỬA Ở DÒNG DƯỚI NÀY: Bỏ .split(' ')[0] đi
            neighbors_str = ', '.join(extra_info)
            log_text.insert(tk.END, f"\nTrùng màu [{color}] với vùng kề: {neighbors_str}\n")
        elif action_type == "BACKTRACK": 
            log_text.insert(tk.END, f"\nHủy màu [{color}] tại vùng: {region}\n")
        log_text.see(tk.END)

    final_assignment = csp.backtracking_search(step_callback=collect_steps)
    if final_assignment:
        result_text.insert(tk.END, str(final_assignment))

    def animate(index):
        if index < len(history_steps):
            region, color, action_type, _ = history_steps[index]
            if action_type == "ADVANCE": canvas.itemconfig(polygon_ids[region], fill=COLOR_MAP[color])
            elif action_type == "BACKTRACK": canvas.itemconfig(polygon_ids[region], fill="#e0e0e0")
            root.after(200, lambda: animate(index + 1))

    root.after(500, lambda: animate(0))
    root.mainloop()

if __name__ == "__main__":
    main()