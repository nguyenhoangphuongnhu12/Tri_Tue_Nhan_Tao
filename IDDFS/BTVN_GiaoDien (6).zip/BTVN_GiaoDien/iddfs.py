import tkinter as tk

def run(center_frame, log_text, result_text, algo_name):
    # DỌN DẸP GIAO DIỆN
    for w in center_frame.winfo_children(): w.destroy()
    log_text.delete("1.0", "end")
    result_text.delete("1.0", "end")

    tk.Label(center_frame, text="VACUUM WORLD - IDDFS", bg="#1e1e1e", fg="#00ffcc", font=("Segoe UI", 18, "bold")).pack(pady=10)

    # Khởi tạo Canvas và Grid giống DFS của bạn
    rows, cols, size = 3, 3, 100
    canvas = tk.Canvas(center_frame, bg="white")
    canvas.pack(fill="both", expand=True)
    canvas.update()
    
    initial_grid = ((0, 1, 0), (1, 1, 0), (0, 0, 1))
    offset_x, offset_y = (canvas.winfo_width() - cols * size) // 2, (canvas.winfo_height() - rows * size) // 2
    
    cells, centers = {}, {}
    for r in range(rows):
        for c in range(cols):
            x1, y1 = offset_x + c * size, offset_y + r * size
            cells[(r, c)] = canvas.create_rectangle(x1, y1, x1+size, y1+size, fill="#ff6666" if initial_grid[r][c] == 1 else "#dddddd", outline="black", width=2)
            centers[(r, c)] = (x1 + size//2, y1 + size//2)

    robot = canvas.create_rectangle(0, 0, 0, 0, fill="#3399ff")
    
    def move_robot(r, c):
        cx, cy = centers[(r, c)]
        canvas.coords(robot, cx-25, cy-25, cx+25, cy+25)

    def is_goal(grid):
        return all(all(cell == 0 for cell in row) for row in grid)

    def clean_grid(grid, r, c):
        new_grid = [list(row) for row in grid]
        new_grid[r][c] = 0
        return tuple(tuple(row) for row in new_grid)

    # THUẬT TOÁN IDDFS
    def iddfs():
        for limit in range(15): # Giới hạn độ sâu
            log_text.insert("end", f"\n>>> ĐANG THỬ VỚI LIMIT = {limit}\n")
            stack = [{"state": ((0, 0), initial_grid), "parent": None, "action": None, "step": 0, "path": [((0, 0), initial_grid)]}]
            reached = {} # Dạng {state: depth}

            while stack:
                node = stack.pop()
                (r, c), grid = node["state"]
                
                # Check reached với depth hiện tại
                if node["state"] in reached and reached[node["state"]] <= node["step"]:
                    continue
                reached[node["state"]] = node["step"]

                # LOG POP
                log_text.insert("end", f"[POP] {r,c} | Step: {node['step']}\n")

                if is_goal(grid):
                    log_text.insert("end", ">>> GOAL FOUND!\n")
                    return node["path"]

                if node["step"] < limit:
                    for act, dr, dc in [("U",-1,0), ("L",0,-1), ("D",1,0), ("R",0,1)]:
                        nr, nc = r+dr, c+dc
                        if 0 <= nr < rows and 0 <= nc < cols:
                            new_grid = clean_grid(grid, nr, nc)
                            child_state = ((nr, nc), new_grid)
                            
                            stack.append({
                                "state": child_state, "parent": node["state"], "action": act,
                                "step": node["step"] + 1, "path": node["path"] + [child_state]
                            })
                            log_text.insert("end", f"  PUSH {nr,nc} (Step {node['step']+1})\n")
        return None

    solution_path = iddfs()

    # ANIMATION
    def animate(index):
        if not solution_path or index >= len(solution_path): return
        (r, c), grid = solution_path[index]
        move_robot(r, c)
        for rr in range(rows):
            for cc in range(cols):
                canvas.itemconfig(cells[(rr, cc)], fill="#ff6666" if grid[rr][cc] == 1 else "#dddddd")
        center_frame.after(600, lambda: animate(index + 1))

    if solution_path: animate(0)
    else: result_text.insert("1.0", "NO SOLUTION FOUND")