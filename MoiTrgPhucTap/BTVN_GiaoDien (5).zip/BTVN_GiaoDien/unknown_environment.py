#https://github.com/nguyenhoangphuongnhu12/Tri_Tue_Nhan_Tao
#Nguyễn Hoàng Phương Như - 24110042
#THUẬT TOÁN TÌM KIẾM TRONG MÔI TRƯỜNG KHÔNG NHÌN THẤY
import tkinter as tk
from collections import deque

# =========================================================
# HÀM BỔ TRỢ: XUẤT MA TRẬN THEO DẠNG DÒNG X CỘT
# =========================================================
def get_matrix_multiline_str(dirty_cells_set, rows=3, cols=3):
    lines = []
    for r in range(rows):
        row_str = []
        for c in range(cols):
            row_str.append("1" if (r, c) in dirty_cells_set else "0")
        lines.append("      " + " ".join(row_str))
    return "\n".join(lines)


# =========================================================
# HÀM TỰ ĐỘNG SINH TÊN THEO THỨ TỰ: A-Z, A1-Z1, A2-Z2,...
# =========================================================
def name_generator():
    letters = [chr(i) for i in range(65, 91)] # 'A' -> 'Z'
    for letter in letters:
        yield letter
    suffix = 1
    while True:
        for letter in letters:
            yield f"{letter}{suffix}"
        suffix += 1


# =========================================================
# 1. LỚP BIỂU DIỄN TRẠNG THÁI ĐƠN LẺ (SINGLE STATE)
# =========================================================
class VacuumState:
    def __init__(self, agent_pos, dirty_cells):
        self.agent_pos = agent_pos                
        self.dirty_cells = frozenset(dirty_cells) 

    def is_goal(self):
        return len(self.dirty_cells) == 0

    def __eq__(self, other):
        return self.agent_pos == other.agent_pos and self.dirty_cells == other.dirty_cells

    def __hash__(self):
        return hash((self.agent_pos, self.dirty_cells))

    def get_detailed_str(self):
        matrix_block = get_matrix_multiline_str(self.dirty_cells, rows=3, cols=3)
        return f"   + Robot ở vị trí {self.agent_pos}\n   + Sơ đồ ma trận ô bẩn:\n{matrix_block}"

    def transition(self, action, rows, cols):
        r, c = self.agent_pos
        new_dirty = set(self.dirty_cells)
        
        if action == "U" and r > 0: r -= 1
        elif action == "D" and r < rows - 1: r += 1
        elif action == "L" and c > 0: c -= 1
        elif action == "R" and c < cols - 1: c += 1
        
        if (r, c) in new_dirty:
            new_dirty.remove((r, c))
            
        return VacuumState((r, c), new_dirty)


# =========================================================
# 2. LỚP NÚT TẬP NIỀM TIN (BELIEF-STATE NODE)
# =========================================================
class BeliefNode:
    def __init__(self, states, parent=None, action=None, step=0, name="A"):
        self.states = frozenset(states) 
        self.parent = parent            
        self.action = action            
        self.step = step                
        self.name = name                 

    def is_goal(self):
        return all(state.is_goal() for state in self.states)

    def get_key(self):
        return self.states


# =========================================================
# 3. THUẬT TOÁN BREADTH-FIRST SEARCH
# =========================================================
def blind_bfs_search(rows, cols, initial_dirty):
    all_positions = [(r, c) for r in range(rows) for c in range(cols)]
    
    gen = name_generator()
    root_name = next(gen)
    
    start_states = []
    for pos in all_positions:
        r, c = pos
        new_dirty = set(initial_dirty)
        if (r, c) in new_dirty:
            new_dirty.remove((r, c))
        start_states.append(VacuumState(pos, new_dirty))
    
    root_node = BeliefNode(states=start_states, parent=None, action=None, step=0, name=root_name)
    
    frontier = deque([root_node])         # Frontier chứa nút gốc
    reached = set()                       # Reached ban đầu trống rỗng, chỉ nạp khi POP
    
    actions_list = ["U", "D", "L", "R"]
    steps_log = []
    
    init_log = f"[KHỞI TẠO HỆ THỐNG BLIND BFS]\n"
    init_log += f"-> [PUSH] Đẩy nút [{root_node.name}] vào Frontier.\n"
    init_log += f"- Số cấu hình niềm tin ban đầu: {len(root_node.states)} trạng thái khả thi.\n"
    steps_log.append(init_log)

    while frontier:
        # 1. POP NÚT RA KHỎI FRONTIER
        curr_node = frontier.popleft()
        curr_key = curr_node.get_key()
        
        # 2. KIỂM TRA TRÙNG TRONG TẬP REACHED KHI POP (Chống duyệt lại nút đã đóng)
        if curr_key in reached:
            continue
            
        # 3. THÊM VÀO TẬP REACHED NGAY KHI POP (Đánh dấu đã thăm đàng hoàng)
        reached.add(curr_key)
        
        log_msg = f"==> [POP] Lấy nút [{curr_node.name}] ra khỏi Frontier (Step {curr_node.step})\n"
        log_msg += f"Đã thêm [{curr_node.name}] vào tập REACHED.\n"
        if curr_node.parent:
            log_msg += f"- Đi từ nút cha: [{curr_node.parent.name}] qua hành động: [{curr_node.action}]\n"
        log_msg += f"- Kích thước Tập niềm tin hiện tại: {len(curr_node.states)} trạng thái.\n"
        log_msg += f"- MA TRẬN CÁC TRẠNG THÁI:\n"
        
        sorted_states = sorted(list(curr_node.states), key=lambda x: (x.agent_pos, len(x.dirty_cells)))
        for idx, state in enumerate(sorted_states, 1):
            log_msg += f"Trạng thái giả định {idx}:\n{state.get_detailed_str()}\n"
            
        log_msg += f"Frontier={len(frontier)} | Reached={len(reached)}\n"
        log_msg += f"------------------------------------------------------------\n"
        
        # 4. GOAL TEST KHI POP
        if curr_node.is_goal():
            log_msg += f"[ĐÍCH ĐẠT ĐƯỢC] Tìm thấy giải pháp tại nút [{curr_node.name}]!"
            steps_log.append(log_msg)
            
            path = []
            temp = curr_node
            while temp is not None:
                path.append(temp)
                temp = temp.parent
            path.reverse() 
            return path, steps_log
        
        child_step = curr_node.step + 1
        push_log_actions = []
        
        # 5. SINH TẬP CON & PUSH VÀO FRONTIER
        for action in actions_list:
            next_states = set()
            for state in curr_node.states:
                next_states.add(state.transition(action, rows, cols))
                
            temp_node = BeliefNode(states=next_states)
            child_key = temp_node.get_key()
            
            # Chỉ sinh con nếu tập niềm tin này chưa nằm trong tập Reached (chưa từng được duyệt qua)
            if child_key not in reached:
                child_name = next(gen)
                child_node = BeliefNode(
                    states=next_states, 
                    parent=curr_node, 
                    action=action, 
                    step=child_step,
                    name=child_name
                )
                
                frontier.append(child_node) # PUSH vào Frontier
                push_log_actions.append(f"[{action}] -> Sinh nút con [{child_node.name}] (Tập niềm tin có {len(next_states)} trạng thái)")
        
        if push_log_actions:
            log_msg += "[PUSH] Các hành động sinh nút con mới đẩy thêm vào Frontier:\n"
            for act_msg in push_log_actions:
                log_msg += f"   + {act_msg}\n"
                
        steps_log.append(log_msg)
                
    return None, steps_log


# =========================================================
# 4. HÀM RUN CHÍNH (GIAO DIỆN TKINTER ĐỒ HỌA)
# =========================================================
def run(center_frame, log_text, result_text, name):
    ROWS, COLS = 3, 3  
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_frame.configure(bg="#ffffff")

    for widget in center_frame.winfo_children():
        widget.destroy()

    log_text.delete("1.0", tk.END)
    result_text.delete("1.0", tk.END)

    title_label = tk.Label(
        center_frame, 
        text="VACUUM WORLD - Blind Search (BFS)", 
        bg="#1a1a1a", 
        fg="#00ffcc", 
        font=("Segoe UI", 16, "bold"), 
        pady=8
    )
    title_label.pack(side="top", fill="x", pady=(10, 10))

    legend_bar = tk.Frame(center_frame, bg="#1a1a1a", pady=6)
    legend_bar.pack(side="top", fill="x", padx=40, pady=(0, 20))

    center_legend = tk.Frame(legend_bar, bg="#1a1a1a")
    center_legend.pack(anchor="center")

    tk.Label(center_legend, bg="#e0e0e0", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 5))
    tk.Label(center_legend, text="0 = CLEAN", bg="#1a1a1a", fg="white", font=("Segoe UI", 9, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#ff6666", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="1 = DIRTY", bg="#1a1a1a", fg="white", font=("Segoe UI", 9, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#99ccff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="LIGHT BLUE = MAYBE ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 9, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#0055ff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="DARK BLUE = CONFIRMED ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 9, "bold")).pack(side="left")

    container = tk.Frame(center_frame, bg="#ffffff")
    container.pack(expand=True)

    CELL_SIZE = 100
    canvas = tk.Canvas(
        container, 
        width=COLS * CELL_SIZE, 
        height=ROWS * CELL_SIZE, 
        bg="#ffffff", 
        highlightthickness=0
    )
    canvas.pack(side="bottom")

    path, steps_log = blind_bfs_search(ROWS, COLS, initial_dirty)
    
    for log_block in steps_log:
        log_text.insert(tk.END, log_block + "\n" + "="*75 + "\n")
    log_text.see(tk.END) 
    log_text.update_idletasks()

    if not path:
        result_text.insert(tk.END, "Kết quả: KHÔNG TÌM THẤY ĐƯỜNG ĐI THỎA MÃN.")
        return

    path_names = [node.name for node in path]
    actions_taken = [node.action for node in path if node.action is not None]
    
    result_text.insert(tk.END, "=== FINAL SOLUTION (CO NAMING BFS) ===\n\n")
    result_text.insert(tk.END, f"Lộ trình các nút:\n{' -> '.join(path_names)}\n\n")
    result_text.insert(tk.END, f"Chuỗi hành động di chuyển:\n{' -> '.join(actions_taken)}\n\n")
    result_text.insert(tk.END, f"Tổng số bước di chuyển (step): {path[-1].step} bước\n\n")
    result_text.insert(tk.END, f"TRẠNG THÁI: ĐÃ TÌM THẤY ĐƯỜNG ĐI!\n")
    result_text.tag_config("success", foreground="green")
    result_text.tag_add("success", "1.0", "end")
    
    # Mảng toàn cục tạm thời để lưu vết các ô XANH ĐẬM (Chắc chắn là Robot) đã đi qua trong Animation hiện tại
    confirmed_history = []

    # =========================================================
    # HÀM CẬP NHẬT GIAO DIỆN VẼ MA TRẬN & ĐƯỜNG ĐI LIÊN TUYẾN
    # =========================================================
    def draw_belief_node(belief_node, current_index):
        canvas.delete("all")
        
        possible_positions = set(state.agent_pos for state in belief_node.states)
        all_dirty_cells = set()
        for state in belief_node.states:
            all_dirty_cells.update(state.dirty_cells)
        
        current_action = belief_node.action if belief_node.action else "START"

        # 1. Nếu tập niềm tin hội tụ về 1 ô duy nhất (Xanh đậm), ghi nhận tọa độ này vào lịch sử đường đi
        if len(possible_positions) == 1:
            pos = list(possible_positions)[0]
            # Chỉ thêm vào nếu bước này chưa được ghi nhận trong mảng confirmed_history
            if len(confirmed_history) <= current_index:
                confirmed_history.append(pos)
        else:
            # Nếu tại bước này robot vẫn đang mơ hồ (nhiều ô xanh nhạt), ta để trống lịch sử của bước này
            if len(confirmed_history) <= current_index:
                confirmed_history.append(None)

        # 2. Tiến hành vẽ các ô lưới ma trận nền
        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                
                is_dirty = (r, c) in all_dirty_cells
                is_possible_agent = (r, c) in possible_positions
                
                if is_possible_agent:
                    if len(possible_positions) == 1:
                        cell_bg = "#0055ff"       # Xanh lam đậm (Confirmed)
                        text_color = "white"
                    else:
                        cell_bg = "#99ccff"       # Xanh lam nhạt (Maybe)
                        text_color = "black"
                    cell_outline = "#ffffff"
                    width_border = 3
                else:
                    if is_dirty:
                        cell_bg = "#ff6666"       # Đỏ: Ô bẩn
                        text_color = "white"
                        cell_outline = "#cc5252"
                    else:
                        cell_bg = "#e0e0e0"       # Xám: Ô sạch
                        text_color = "#444444"
                        cell_outline = "#b8b8b8"
                    width_border = 1

                canvas.create_rectangle(x1, y1, x2, y2, fill=cell_bg, outline=cell_outline, width=width_border)
                
                matrix_val = "1" if is_dirty else "0"
                canvas.create_text(
                    x1 + CELL_SIZE/2, 
                    y1 + CELL_SIZE/2 - 10 if is_possible_agent else y1 + CELL_SIZE/2, 
                    text=matrix_val, 
                    fill=text_color, 
                    font=("Consolas", 20, "bold")
                )
                
                if is_possible_agent:
                    label_text = "ROBOT" if len(possible_positions) == 1 else "MAYBE"
                    canvas.create_text(
                        x1 + CELL_SIZE/2, 
                        y1 + CELL_SIZE/2 + 18, 
                        text=label_text, 
                        fill=text_color, 
                        font=("Segoe UI", 9, "bold")
                    )

        # 3. THÊM VÀO ĐÂY: Vẽ nét đường nối liên tiếp xuyên tâm các ô đã đi qua (y hệt ảnh mẫu)
        # Duyệt qua lịch sử confirmed_history từ đầu đến vị trí index hiện tại
        for i in range(current_index):
            p1 = confirmed_history[i]
            p2 = confirmed_history[i+1]
            
            # Chỉ vẽ mũi tên kết nối nếu CẢ HAI bước liên tiếp đều đã định vị được robot chính xác (Xanh đậm)
            if p1 is not None and p2 is not None:
                r1, c1 = p1
                r2, c2 = p2
                
                # Tính tâm ô xuất phát
                line_x1 = c1 * CELL_SIZE + CELL_SIZE / 2
                line_y1 = r1 * CELL_SIZE + CELL_SIZE / 2
                # Tính tâm ô đích đến
                line_x2 = c2 * CELL_SIZE + CELL_SIZE / 2
                line_y2 = r2 * CELL_SIZE + CELL_SIZE / 2
                
                # Vẽ mũi tên màu xanh đậm (Royal Blue) xuyên tâm kết nối các ô vuông giống ảnh mẫu của bạn
                canvas.create_line(
                    line_x1, line_y1, line_x2, line_y2, 
                    fill="#0022cc", width=4, arrow=tk.LAST, arrowshape=(10, 12, 4)
                )

    # =========================================================
    # ĐIỀU KHIỂN HOẠT ẢNH ANIMATION TỪNG BƯỚC LỘ TRÌNH
    # =========================================================
    def animate(step_index):
        if step_index < len(path):
            current_node = path[step_index]
            draw_belief_node(current_node, step_index)
            center_frame.after(1000, lambda: animate(step_index + 1)) 

    # Khởi động lại mảng lịch sử mỗi lần chạy hoạt ảnh mới
    confirmed_history.clear()
    animate(0)