# https://github.com/nguyenhoangphuongnhu12/Tri_Tue_Nhan_Tao
# Nguyễn Hoàng Phương Như - 24110042
# THUẬT TOÁN LEO ĐỒI KHỞI ĐỘNG NGẪU NHIÊN (RANDOM RESTART HILL CLIMBING) - BẢN CẬP NHẬT ANIMATION RESTART
import tkinter as tk # Thư viện giao diện
import copy # Thư viện sao chép đối tượng
import random # Thư viện sinh ngẫu nhiên

# =========================================================
# LỚP BIỂU DIỄN TRẠNG THÁI MÁY HÚT BỤI
# =========================================================
class VacuumState:
    """Lớp này chứa toàn bộ thông tin về một trạng thái của ma trận"""
    def __init__(self, agent_pos, dirty_cells, parent=None, action=None, step=0, name="S"):
        self.agent_pos = agent_pos # Vị trí hiện tại của Robot (r, c)
        self.dirty_cells = set(dirty_cells) # Tập hợp các ô dơ (Tạo set để xử lý nhanh)
        self.parent = parent # Nút cha (nút dẫn đến nút này)
        self.action = action # Hành động (U, D, L, R) để đạt được trạng thái này
        self.step = step # Số bước đi tính từ nút gốc
        self.h = len(self.dirty_cells) # Hàm heuristic (h): số lượng ô rác (càng nhỏ càng tốt)
        self.name = name # Tên nút (dùng để in lộ trình dạng 'S -> A -> B')

    def is_goal(self):
        """Kiểm tra xem trạng thái đã sạch rác chưa"""
        return len(self.dirty_cells) == 0

    def generate_successors(self, rows, cols):
        """Sinh ra tập hợp các trạng thái con lân cận (di chuyển 4 hướng)"""
        successors = []
        r, c = self.agent_pos # Vị trí hiện tại của Robot
        moves = [("U", r-1, c), ("D", r+1, c), ("L", r, c-1), ("R", r, c+1)] # 4 hướng di chuyển
        
        for action, nr, nc in moves:
            # Kiểm tra xem ô mới có nằm trong phạm vi ma trận không
            if 0 <= nr < rows and 0 <= nc < cols:
                # Tạo bản sao sâu của set rác để tránh ảnh hưởng dữ liệu nút cha
                new_dirty = copy.deepcopy(self.dirty_cells)
                # Nếu ô di chuyển tới có rác, ta dọn sạch ô đó
                if (nr, nc) in new_dirty:
                    new_dirty.remove((nr, nc))
                
                # Tạo trạng thái mới và thêm vào danh sách successors
                successors.append(VacuumState((nr, nc), new_dirty, self, action, self.step + 1))
        return successors

    @staticmethod
    def generate_random_start(rows, cols, num_dirty_cells=4):
        """Hàm sinh ngẫu nhiên một trạng thái gốc hoàn toàn mới khi cần Restart"""
        # Sinh vị trí robot ngẫu nhiên (r, c)
        random_agent = (random.randint(0, rows - 1), random.randint(0, cols - 1))
        
        # Sinh danh sách tất cả các ô có thể
        all_cells = [(r, c) for r in range(rows) for c in range(cols)]
        # Chọn ngẫu nhiên num_dirty_cells ô để đặt rác
        random_dirty = random.sample(all_cells, min(num_dirty_cells, len(all_cells)))
        
        # Nếu ô di chuyển ngẫu nhiên của Robot trùng vào ô rác ban đầu, 
        # ta dọn sạch luôn ô đó để khớp với logic game.
        if random_agent in random_dirty:
            random_dirty.remove(random_agent)
            
        return VacuumState(random_agent, random_dirty, name="S")

# =========================================================
# HÀM BỔ TRỢ ĐỂ IN LOG RA CONSOLE
# =========================================================
def get_matrix_str(dirty_cells, rows=3, cols=3):
    """Hàm này biến trạng thái rác thành một chuỗi dạng 0 1 để in log"""
    lines = []
    for r in range(rows):
        row_str = ["1" if (r, c) in dirty_cells else "0" for c in range(cols)]
        lines.append(" ".join(row_str))
    return "\n".join(lines)

# =========================================================
# THUẬT TOÁN LEO ĐỒI KHỞI ĐỘNG NGẪU NHIÊN (RANDOM RESTART HILL CLIMBING)
# =========================================================
def random_restart_hill_climbing_search(start_pos, initial_dirty, ROWS, COLS, MAX_RESTART=5):
    """
    Hàm thuật toán chính.
    MAX_RESTART: Số lần thử lại tối đa từ trạng thái ngẫu nhiên.
    Returns:
    path: Lộ trình của lượt chạy cuối (có thể thành công hoặc thất bại)
    steps_log: Nhật ký chi tiết để in ra log_text
    all_runs_paths: Danh sách lộ trình của *tất cả* các lần chạy (kể cả bị kẹt)
    """
    # Khởi tạo trạng thái ban đầu của hệ thống
    start_node = VacuumState(start_pos, initial_dirty, name="S")
    steps_log = ["--- BẮT ĐẦU LEO ĐỒI KHỞI ĐỘNG NGẪU NHIÊN ---"]
    node_counter = 0 # Biến đếm để đặt tên nút (A, B, C...)
    
    # Danh sách lưu lộ trình của TẤT CẢ các lượt chạy thử
    all_runs_paths = [] 

    # --- VÒNG LẶP NGOÀI: Tái khởi động (Restart) ---
    for i in range(1, MAX_RESTART + 1):
        steps_log.append(f"\n================ LƯỢT CHẠY THỨ {i} ================")
        
        # Xác định trạng thái bắt đầu của lượt chạy này
        if i == 1:
            current = start_node # Lượt 1: dùng trạng thái cố định ban đầu
        else:
            # Lượt sau: sinh một trạng thái ngẫu nhiên hoàn toàn mới
            current = VacuumState.generate_random_start(ROWS, COLS, num_dirty_cells=len(initial_dirty))
            
        path = [current] # Tạo lộ trình riêng biệt cho lượt chạy hiện tại

        # --- VÒNG LẶP TRONG: Leo đồi Steepest-Ascent ---
        while True:
            # 1. Kiểm tra trạng thái mục tiêu
            if current.is_goal():
                log_chunk = [
                    f"[GOAL REACHED] NODE: {current.name} (Robot={current.agent_pos})",
                    f"-> Tìm thấy trạng thái ĐÍCH ở lượt chạy thứ {i}!"
                ]
                steps_log.append("\n".join(log_chunk))
                all_runs_paths.append(path) # Lưu lượt chạy thành công cuối cùng
                return path, steps_log, all_runs_paths # TRẢ VỀ: Thành công!
            
            # 2. Sinh các trạng thái con lân cận
            successors = current.generate_successors(ROWS, COLS)
            
            # Ghi nhật ký trạng thái hiện tại
            log_chunk = [
                f"[POP] NODE: {current.name} (Robot={current.agent_pos})",
                f"Parent: {current.parent.name if current.parent else 'None'} | Action: {current.action} | h={current.h}",
                f"\n{get_matrix_str(current.dirty_cells, ROWS, COLS)}",
                "EXPAND & LỌC TẬP BETTER NEIGHBORS:"
            ]

            # 3. Lọc ra tập 'Better Neighbors' (có h(n) nhỏ hơn trạng thái hiện tại)
            better_successors = []
            for succ in successors:
                node_counter += 1
                # Gán tên cho nút mới sinh (dạng A1, B1, C1... tránh lỗi chr(>127))
                succ.name = chr(65 + (node_counter % 26)) + str(node_counter // 26 if node_counter >= 26 else "")
                
                # Ghi nhật ký các nút con
                log_chunk.append(f"  [NODE CON {succ.name}] (Robot={succ.agent_pos}) | h={succ.h}")
                
                # Nếu h(n) nhỏ hơn h của hiện tại, nó là tốt hơn (do đang tìm cực tiểu)
                if succ.h < current.h:
                    better_successors.append(succ)
            
            # 4. Kiểm tra xem có trạng thái nào tốt hơn không (Xử lý KẸT)
            if not better_successors:
                # Better_Neighbors RỖNG -> Robot bị kẹt ở cực trị địa phương
                log_chunk.append("-> KHÔNG CÓ LỰA CHỌN TỐT HƠN (BỊ KẸT)!")
                log_chunk.append(f"-> Chuẩn bị RESTART sang lượt {i + 1} (Nếu còn lượt).")
                steps_log.append("\n".join(log_chunk))
                all_runs_paths.append(path) # Lưu lại lộ trình lượt này trước khi break
                break # Thoát vòng lặp while trong, quay về vòng lặp for ngoài (Restart)
                
            else:
                # Better_Neighbors KHÁC RỖNG -> Tiếp tục leo đồi
                # Chọn trạng thái tốt nhất trong tập Better (h thấp nhất) - Steepest Ascent
                min_h = min(succ.h for succ in better_successors)
                best_successors = [succ for succ in better_successors if succ.h == min_h]
                chosen = random.choice(best_successors) # Nếu nhiều Best bằng nhau, chọn ngẫu nhiên
                
                log_chunk.append(f"-> CHỌN Node tốt nhất {chosen.name} (h={chosen.h} trong số {len(better_successors)} node)")
                steps_log.append("\n".join(log_chunk))
                
                # Cập nhật trạng thái hiện tại và thêm vào lộ trình lượt
                current = chosen
                path.append(current)
                
    # Nếu vòng lặp for ngoài kết thúc mà không 'return' -> THẤT BẠI
    steps_log.append(f"\n-> THẤT BẠI: Đã chạy hết sạch {MAX_RESTART} lượt restart mà không chạm được Goal!")
    # Trả về lộ trình của lần chạy bị kẹt cuối cùng để animation
    return path, steps_log, all_runs_paths

# =========================================================
# HÀM RUN CHÍNH (XỬ LÝ GIAO DIỆN TKINTER)
# =========================================================
def run(center_frame, log_text, result_text, name):
    """
    Hàm này kết nối thuật toán với giao diện của bạn
    name: 'Vacuum World - Random Restart Hill Climbing'
    """
    ROWS, COLS = 3, 3  # Phạm vi ma trận ô
    start_pos = (0, 0) # Vị trí cố định ban đầu lượt 1
    # Danh sách ô rác cố định lượt 1
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)] 
    MAX_RESTART = 5  # Số lần restart tối đa được quy định thêm vào

    # 1. Reset giao diện
    center_frame.configure(bg="#ffffff")
    for widget in center_frame.winfo_children():
        widget.destroy()
    log_text.delete("1.0", tk.END)
    result_text.delete("1.0", tk.END)

    # 2. Tạo tiêu đề và chú thích
    title_label = tk.Label(center_frame, text="VACUUM WORLD - Random Restart Hill Climbing", bg="#1a1a1a", fg="#00ffcc", font=("Segoe UI", 20, "bold"), pady=8)
    title_label.pack(side="top", fill="x", pady=(10, 10))
    legend_bar = tk.Frame(center_frame, bg="#1a1a1a", pady=6); legend_bar.pack(side="top", fill="x", padx=40, pady=(0, 20))
    center_legend = tk.Frame(legend_bar, bg="#1a1a1a"); center_legend.pack(anchor="center")
    tk.Label(center_legend, bg="#e0e0e0", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 5))
    tk.Label(center_legend, text="0 = CLEAN CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
    tk.Label(center_legend, bg="#ff6666", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="1 = DIRTY CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
    tk.Label(center_legend, bg="#3399ff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="BLUE = ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    # 3. Tạo Canvas vẽ ma trận
    container = tk.Frame(center_frame, bg="#ffffff"); container.pack(expand=True)
    CELL_SIZE = 100
    canvas = tk.Canvas(container, width=COLS * CELL_SIZE, height=ROWS * CELL_SIZE, bg="#ffffff", highlightthickness=0)
    canvas.pack(side="bottom")

    # 4. Gọi thuật toán, lấy thêm danh sách all_runs_paths
    path, steps_log, all_runs_paths = random_restart_hill_climbing_search(start_pos, initial_dirty, ROWS, COLS, MAX_RESTART)
    
    # In toàn bộ log thuật toán
    for log_block in steps_log:
        log_text.insert(tk.END, log_block + "\n" + "="*40 + "\n")
    log_text.see(tk.END) # Tự động cuộn xuống dưới cùng
    log_text.update_idletasks() # Ép giao diện cập nhật ngay

    if not path or len(path) == 0:
        result_text.insert(tk.END, "Kết quả: KHÔNG TÌM THẤY ĐƯỜNG ĐI!")
        return

    # 5. Xử lý hiển thị text kết quả cuối cùng (Final Statistic)
    result_text.insert(tk.END, f"=== RESTART STATISTICS ===\nTổng số lượt chạy thử: {len(all_runs_paths)} lượt.\n\n")
    
    last_node = path[-1] # Lấy nút cuối của lượt chạy cuối cùng
    if last_node.is_goal():
        result_text.insert(tk.END, f"TRẠNG THÁI: THÀNH CÔNG (Tìm thấy Đích ở lượt thứ {len(all_runs_paths)})!")
        result_text.tag_config("success", foreground="green")
        result_text.tag_add("success", "1.0", "end")
        
        # --- CHỖ CUỐI CÙNG IN LỘ TRÌNH ĐƯỜNG ĐI ĐẾN ĐÍCH ---
        # 1. Phân tách danh sách path trả về (dựa trên h-value/tập rác) để tạo log đường đi
        final_path_details = []
        for state in path:
            final_path_details.append(f"[Step {len(final_path_details)}: Robot={state.agent_pos}, tập ô dơ={get_matrix_str(state.dirty_cells)}, h={state.h}]")
        
        # 2. Tạo tiêu đề log lộ trình trong giao diện (result_text)
        result_text.insert(tk.END, "\n" + "="*20 + " FINAL SOLUTION " + "="*20 + "\n\n")
        
        # 3. In tiêu đề con đường đi dạng ký tự (S -> A -> B...)
        path_names = [node.name for node in path]
        result_text.insert(tk.END, "Lộ trình các nút đường đi: " + " -> ".join(path_names) + "\n\n")
        
        # 4. CHỈ IN TỌA ĐỘ ĐƯỜNG ĐI (ĐÃ CHỈNH SỬA)
        result_text.insert(tk.END, "Tọa độ các bước di chuyển:\n")
        coords_str = " -> ".join([str(state.agent_pos) for state in path])
        result_text.insert(tk.END, coords_str + "\n\n")

        # 3. Ép log kết quả hiển thị đường đi (result_text) tự động cuộn
        result_text.see(tk.END)
        result_text.update_idletasks()
            
        # 5. Ép log kết quả hiển thị đường đi (result_text) tự động cuộn
        result_text.see(tk.END)
        result_text.update_idletasks()
        
    else:
        result_text.insert(tk.END, f"TRẠNG THÁI: THẤT BẠI (Bị kẹt sau cả {MAX_RESTART} lượt)!")
        result_text.tag_config("fail", foreground="red")
        result_text.tag_add("fail", "1.0", "end")
        
    # =========================================================
    # HÀM CẬP NHẬT VẼ MA TRẬN (Được animation điều khiển)
    # state: một nút cụ thể, current_path: lộ trình của lượt chạy đó
    # =========================================================
    def draw_state(current_path, state, step_index):
        """Vẽ ma trận ô (rác, robot) và đường nối giữa các bước"""
        canvas.delete("all")
        
        # Vẽ nền ma trận (ô sạch, ô dơ, ô robot)
        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                is_dirty = (r, c) in state.dirty_cells
                matrix_val = "1" if is_dirty else "0" # Giá trị dạng text 0 1
                
                # Phối màu tùy trạng thái
                if (r, c) == state.agent_pos:
                    # Ô chứa Robot
                    cell_bg = "#3399ff"; text_color = "white"; cell_outline = "#ffffff"; width_border = 3
                else:
                    # Ô khác
                    if is_dirty:
                        # Ô dơ
                        cell_bg = "#ff6666"; text_color = "white"; cell_outline = "#cc5252"
                    else:
                        # Ô sạch
                        cell_bg = "#e0e0e0"; text_color = "#444444"; cell_outline = "#b8b8b8"
                    width_border = 1

                # Vẽ ô lưới
                canvas.create_rectangle(x1, y1, x2, y2, fill=cell_bg, outline=cell_outline, width=width_border)
                
                # Vẽ text 0 hoặc 1 (dùng font Consolas cho đẹp)
                canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2 - 10 if (r, c) == state.agent_pos else y1 + CELL_SIZE/2, text=matrix_val, fill=text_color, font=("Consolas", 20, "bold"))
                
                # Nếu là ô robot, thêm nhãn text "ROBOT"
                if (r, c) == state.agent_pos:
                    canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2 + 18, text="ROBOT", fill="white", font=("Segoe UI", 10, "bold"))

        # Vẽ đường nối màu xanh đậm (dựa trên các bước đã duyệt của lộ trình lượt đó)
        if step_index > 0:
            for i in range(step_index):
                r1, c1 = current_path[i].agent_pos
                r2, c2 = current_path[i+1].agent_pos
                
                # Tính toán tọa độ tâm ô
                line_x1 = c1 * CELL_SIZE + CELL_SIZE / 2
                line_y1 = r1 * CELL_SIZE + CELL_SIZE / 2
                line_x2 = c2 * CELL_SIZE + CELL_SIZE / 2
                line_y2 = r2 * CELL_SIZE + CELL_SIZE / 2
                
                # Vẽ nét nối xuyên tâm ô (ARROW.LAST tạo mũi tên hướng)
                canvas.create_line(line_x1, line_y1, line_x2, line_y2, fill="#0022cc", width=4, arrow=tk.LAST)

    # =========================================================
    # VÒNG LẶP HÀM ĐIỀU KHIỂN ANIMATION ĐA TẦNG (CẬP NHẬT RESTART)
    # run_index: Số lượt chạy, step_index: Số bước đi của lượt đó
    # =========================================================
    def animate_all_runs(run_index, step_index):
        """Hàm animation tự động chuyển qua lại giữa các lượt Restart"""
        if run_index < len(all_runs_paths):
            # Lấy lộ trình cụ thể của LƯỢT CHẠY thứ run_index
            current_path = all_runs_paths[run_index]
            
            if step_index < len(current_path):
                # VẼ trạng thái bước hiện tại trong lượt
                current_state = current_path[step_index]
                draw_state(current_path, current_state, step_index)
                
                # In thông báo lượt chạy ngay trên Canvas để dễ theo dõi
                canvas.create_text(20, 20, text=f"RUN #{run_index + 1}", fill="yellow", font=("Segoe UI", 12, "bold"), anchor="w")
                
                # Đặt lịch hẹn gọi lại: Bước tiếp theo trong lượt này sau 0.6 giây
                center_frame.after(600, lambda: animate_all_runs(run_index, step_index + 1))
            else:
                # Robot đi hết bước của lượt này nhưng chưa đến đích tổng thể -> BỊ KẸT
                # Nếu chưa chạy hết tổng số lượt thử -> HIỂN THỊ RESTART TRÊN CANVAS
                if run_index < len(all_runs_paths) - 1:
                    # Tạo hiệu ứng thông báo RESTART trực quan trên giao diện
                    # Tạo một lớp phủ màu đỏ nhạt, stipple=gray50 cho hiệu ứng mờ
                    canvas.create_rectangle(0, 0, COLS*CELL_SIZE, ROWS*CELL_SIZE, fill="#ff1a1a", stipple="gray50")
                    canvas.create_text(COLS*CELL_SIZE/2, ROWS*CELL_SIZE/2, text="KẸT! ĐANG RESTART...", fill="white", font=("Segoe UI", 16, "bold"))
                    
                    # Đặt lịch hẹn: Chuyển sang LƯỢT CHẠY TIẾP THEO (run_index + 1) sau 1.2 giây trì hoãn
                    # Lúc này step_index của lượt mới reset về 0
                    center_frame.after(1200, lambda: animate_all_runs(run_index + 1, 0))
        else:
            # Thuật toán hoàn tất (thành công hoặc thất bại cuối cùng)
            pass

    # BẮT ĐẦU CHẠY ANIMATION TỪ LƯỢT 1, BƯỚC 0
    animate_all_runs(0, 0)