# https://github.com/nguyenhoangphuongnhu12/Tri_Tue_Nhan_Tao
# Nguyễn Hoàng Phương Như - 24110042
# THUẬT TOÁN LOCAL BEAM SEARCH
import tkinter as tk
import copy

# =========================================================
# LỚP BIỂU DIỄN TRẠNG THÁI MÁY HÚT BỤI
# =========================================================
class VacuumState:
    def __init__(self, agent_pos, dirty_cells, parent=None, action=None, step=0, name="S"):
        self.agent_pos = agent_pos        # Vị trí Robot (r, c)
        self.dirty_cells = set(dirty_cells) # Tập các ô dơ (set để xử lý nhanh)
        self.parent = parent              # Nút cha để truy vết đường đi
        self.action = action              # Hành động đã thực hiện (U, D, L, R)
        self.step = step                  # Độ sâu của nút trong cây tìm kiếm
        self.name = name                  # Tên nút (ví dụ: A, B1, C2...)
        # Heuristic Manhattan: Tổng khoảng cách từ robot đến tất cả các ô dơ
        self.h = self.calculate_manhattan_h() 

    def calculate_manhattan_h(self):
        """Tính tổng khoảng cách Manhattan từ robot đến mọi ô rác còn lại."""
        if not self.dirty_cells: return 0
        r, c = self.agent_pos
        # Công thức: |r_robot - r_rác| + |c_robot - c_rác|
        return sum(abs(r - dr) + abs(c - dc) for (dr, dc) in self.dirty_cells)

    def is_goal(self):
        """Kiểm tra trạng thái đích (không còn ô nào bẩn)."""
        return len(self.dirty_cells) == 0

    def generate_successors(self, rows, cols):
        """Sinh các trạng thái kế tiếp (4 hướng di chuyển cơ bản)."""
        successors = []
        r, c = self.agent_pos
        # Chỉ di chuyển lên, xuống, trái, phải
        moves = [("U", r-1, c), ("D", r+1, c), ("L", r, c-1), ("R", r, c+1)]
        
        for action, nr, nc in moves:
            # Kiểm tra biên ma trận
            if 0 <= nr < rows and 0 <= nc < cols:
                new_dirty = copy.deepcopy(self.dirty_cells)
                # Nếu ô đích có rác, robot sẽ hút sạch (h giảm xuống)
                if (nr, nc) in new_dirty:
                    new_dirty.remove((nr, nc))
                
                # Tạo node con với các thông tin đầy đủ
                new_state = VacuumState((nr, nc), new_dirty, self, action, self.step + 1)
                successors.append(new_state)
        return successors

# =========================================================
# HÀM BỔ TRỢ ĐỊNH DẠNG LOG
# =========================================================
def get_matrix_str(dirty_cells, rows=3, cols=3):
    """Chuyển đổi tập ô rác thành chuỗi ma trận 0/1 để hiển thị trong log."""
    lines = []
    for r in range(rows):
        row_str = ["1" if (r, c) in dirty_cells else "0" for c in range(cols)]
        lines.append(" ".join(row_str))
    return "\n".join(lines)

# =========================================================
# THUẬT TOÁN LOCAL BEAM SEARCH
# =========================================================
def local_beam_search(start_pos, initial_dirty, ROWS, COLS, k=3):
    # Khởi tạo k nút ban đầu (Thế hệ 0)
    current_nodes = [VacuumState(start_pos, initial_dirty, name=chr(65+i)) for i in range(k)]
    path = [current_nodes[0]]
    steps_log = ["--- BẮT ĐẦU LOCAL BEAM SEARCH ---"]
    
    generation = 0
    while True:
        generation += 1
        all_successors = []
        
        steps_log.append(f"\n[POP] THẾ HỆ {generation-1} (Chùm hiện tại):")
        
        # 2.1 SINH TOÀN BỘ LÂN CẬN TỪ TẤT CẢ CÁC NÚT TRONG CHÙM
        for node in current_nodes:
            # Ghi log trạng thái của node cha trước khi mở rộng
            steps_log.append(f"  - Node {node.name} | Robot: {node.agent_pos} | h={node.h}")
            steps_log.append(f"\n{get_matrix_str(node.dirty_cells, ROWS, COLS)}")
            
            # Kiểm tra đích cho từng neighbor (theo mã giả 2.2)
            successors = node.generate_successors(ROWS, COLS)
            
            # Ghi chú: Gạch đầu cụm PUSH cho node cha này
            steps_log.append("="*60) 
            for i, succ in enumerate(successors):
                # Đặt tên: Cha + STT con
                succ.name = f"{node.name}{i+1}"
                all_successors.append(succ)
                
                log_push = (
                    f"    [PUSH Node {succ.name}] | Robot: {succ.agent_pos} | Action: {succ.action} | h={succ.h}\n"
                    f"{get_matrix_str(succ.dirty_cells, ROWS, COLS)}"
                )
                steps_log.append(log_push)
            steps_log.append("="*40) # Gạch cuối cụm
        
        # 2.2. KIỂM TRA ĐÍCH 
        # Kiểm tra xem có node nào trong all_successors là Goal không
        for succ in all_successors:
            if succ.is_goal():
                steps_log.append(f"-> ĐÃ TÌM THẤY ĐÍCH tại node {succ.name}")
                path.append(succ)
                return path, steps_log

        if not all_successors:
            steps_log.append("-> THUẬT TOÁN BỊ KẸT!")
            break
            
        # 2.3 LỰA CHỌN CHÙM VÀ BÁO CÁO
        all_successors.sort(key=lambda x: x.h)
        current_nodes = all_successors[:k]
        
        # BÁO CÁO: Ghi tên và h của k node vừa chọn trước khi POP tiếp
        steps_log.append(f"\n=> Đã chọn {len(current_nodes)} node tốt nhất để làm chùm cho thế hệ tiếp theo:")
        for node in current_nodes:
            steps_log.append(f"   - Node {node.name} (h={node.h})")
        
        # Cập nhật đường đi (nút đầu tiên của chùm mới)
        path.append(current_nodes[0]) 

    return path, steps_log

# =========================================================
# HÀM RUN CHÍNH (GIAO DIỆN TKINTER - KHÔNG CHỈNH SỬA)
# =========================================================
def run(center_frame, log_text, result_text, name):
    ROWS, COLS = 3, 3  
    start_pos = (0, 0) 
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_frame.configure(bg="#ffffff")
    for widget in center_frame.winfo_children():
        widget.destroy()

    title_label = tk.Label(center_frame, text="VACUUM WORLD - Local Beam Search", bg="#1a1a1a", fg="#00ffcc", font=("Segoe UI", 20, "bold"), pady=8)
    title_label.pack(side="top", fill="x", pady=(10, 10))

    legend_bar = tk.Frame(center_frame, bg="#1a1a1a", pady=6)
    legend_bar.pack(side="top", fill="x", padx=40, pady=(0, 20))
    center_legend = tk.Frame(legend_bar, bg="#1a1a1a")
    center_legend.pack(anchor="center")
    tk.Label(center_legend, bg="#e0e0e0", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 5))
    tk.Label(center_legend, text="0 = CLEAN CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
    tk.Label(center_legend, bg="#ff6666", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="1 = DIRTY CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
    tk.Label(center_legend, bg="#3399ff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="BLUE = ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    container = tk.Frame(center_frame, bg="#ffffff")
    container.pack(expand=True)
    CELL_SIZE = 100
    canvas = tk.Canvas(container, width=COLS * CELL_SIZE, height=ROWS * CELL_SIZE, bg="#ffffff", highlightthickness=0)
    canvas.pack(side="bottom")

    path, steps_log = local_beam_search(start_pos, initial_dirty, ROWS, COLS)
    
    log_text.delete("1.0", tk.END)
    for log_block in steps_log:
        log_text.insert(tk.END, log_block + "\n\n")
    log_text.see(tk.END) 
    log_text.update_idletasks()

    result_text.delete("1.0", tk.END)
    if not path or len(path) == 0:
        result_text.insert(tk.END, "Kết quả: KHÔNG TÌM THẤY ĐƯỜNG ĐI!")
        return

    path_names = [node.name for node in path]
    path_coords = [str(node.agent_pos) for node in path]
    result_text.insert(tk.END, "=== FINAL SOLUTION ===\n\n")
    result_text.insert(tk.END, f"Lộ trình các nút:\n{' -> '.join(path_names)}\n\n")
    result_text.insert(tk.END, f"Tọa độ di chuyển:\n{' -> '.join(path_coords)}\n\n")
    
    last_node = path[-1]
    if last_node.is_goal():
        result_text.insert(tk.END, "TRẠNG THÁI: THÀNH CÔNG (Đã dọn sạch)!")
    else:
        result_text.insert(tk.END, "TRẠNG THÁI: BỊ KẸT (Cực trị địa phương)!")
        
    def draw_state(state, step_index):
        canvas.delete("all")
        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                is_dirty = (r, c) in state.dirty_cells
                if (r, c) == state.agent_pos:
                    cell_bg, text_color, width_border = "#3399ff", "white", 3
                else:
                    cell_bg, text_color, width_border = ("#ff6666", "white", 1) if is_dirty else ("#e0e0e0", "#444444", 1)
                canvas.create_rectangle(x1, y1, x2, y2, fill=cell_bg, outline="white", width=width_border)
                canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2, text="1" if is_dirty else "0", fill=text_color, font=("Consolas", 20, "bold"))
                if (r, c) == state.agent_pos:
                    canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2 + 18, text="ROBOT", fill="white", font=("Segoe UI", 10, "bold"))
        if step_index > 0:
            for i in range(step_index):
                r1, c1 = path[i].agent_pos
                r2, c2 = path[i+1].agent_pos
                canvas.create_line(c1*CELL_SIZE + CELL_SIZE/2, r1*CELL_SIZE + CELL_SIZE/2, c2*CELL_SIZE + CELL_SIZE/2, r2*CELL_SIZE + CELL_SIZE/2, fill="#0022cc", width=4, arrow=tk.LAST)

    def animate(step_index):
        if step_index < len(path):
            draw_state(path[step_index], step_index)
            center_frame.after(600, lambda: animate(step_index + 1))
    animate(0)