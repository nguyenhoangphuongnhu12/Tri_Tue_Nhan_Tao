# https://github.com/nguyenhoangphuongnhu12/Tri_Tue_Nhan_Tao
# Nguyễn Hoàng Phương Như - 24110042
# THUẬT TOÁN SIMULATED ANNEALING
import tkinter as tk
import copy
import random
import math

# =========================================================
# LỚP BIỂU DIỄN TRẠNG THÁI (VacuumState)
# =========================================================
class VacuumState:
    def __init__(self, agent_pos, dirty_cells, parent=None, action=None, step=0, name="S"):
        self.agent_pos = agent_pos        # Tọa độ (r, c) của robot
        self.dirty_cells = set(dirty_cells) # Tập hợp các ô bẩn (dùng set để thao tác nhanh)
        self.parent = parent              # Nút cha để truy vết đường đi
        self.action = action              # Hành động dẫn tới trạng thái này
        self.step = step                  # Độ sâu của nút trong cây tìm kiếm
        self.name = name                  # Tên định danh (VD: A, B, C...)
        # Tính Heuristic Manhattan: Tổng khoảng cách từ robot đến mọi ô rác
        self.h = self.calculate_manhattan_h() 

    def calculate_manhattan_h(self):
        """Tính giá trị Heuristic Manhattan."""
        if not self.dirty_cells: return 0
        r, c = self.agent_pos
        return sum(abs(r - dr) + abs(c - dc) for (dr, dc) in self.dirty_cells)

    def is_goal(self):
        """Kiểm tra điều kiện đích: Không còn ô bẩn nào."""
        return len(self.dirty_cells) == 0

    def generate_successors(self, rows, cols):
        """Sinh các trạng thái lân cận (hàng xóm)."""
        successors = []
        r, c = self.agent_pos
        # Các hành động có thể: Lên, Xuống, Trái, Phải
        moves = [("U", r-1, c), ("D", r+1, c), ("L", r, c-1), ("R", r, c+1)]
        
        for action, nr, nc in moves:
            # Kiểm tra biên ma trận
            if 0 <= nr < rows and 0 <= nc < cols:
                new_dirty = copy.deepcopy(self.dirty_cells)
                # Nếu di chuyển vào ô bẩn, robot sẽ dọn sạch
                if (nr, nc) in new_dirty:
                    new_dirty.remove((nr, nc))
                # Tạo node con mới
                new_node = VacuumState((nr, nc), new_dirty, self, action, self.step + 1)
                successors.append(new_node)
        return successors

# Hàm bổ trợ để in ma trận trạng thái ra log
def get_matrix_str(dirty_cells, rows=3, cols=3):
    lines = []
    for r in range(rows):
        row_str = ["1" if (r, c) in dirty_cells else "0" for c in range(cols)]
        lines.append(" ".join(row_str))
    return "\n".join(lines)

# =========================================================
# THUẬT TOÁN SIMULATED ANNEALING 
# =========================================================
def simulated_annealing(start_pos, initial_dirty, ROWS, COLS, T0=100, alpha=0.75, Tmin = 10):
    # Khởi tạo trạng thái ban đầu (Node A)
    current = VacuumState(start_pos, initial_dirty, name="A")
    T = T0 # Thiết lập nhiệt độ ban đầu
    path = [current]
    steps_log = ["--- BẮT ĐẦU SIMULATED ANNEALING ---"]
    
    
    # Vòng lặp TRONG KHI T > Tmin 
    loop = 1
    while T > Tmin:
        # Kiểm tra đích
        if current.is_goal():
            steps_log.append("-> ĐÃ TÌM THẤY ĐÍCH!")
            return path, steps_log
        
        # 1. Sinh ngẫu nhiên một trạng thái lân cận (RandomNeighbor)
        successors = current.generate_successors(ROWS, COLS)
        if not successors: break
        # Chọn ngẫu nhiên một trạng thái lân cận
        next_s = random.choice(successors)
        
        # ĐẶT TÊN THEO YÊU CẦU:
        # Lấy ký tự dựa trên số vòng lặp (A, B, C...)
        # Lấy chỉ số con dựa trên index trong danh sách successors (A1, A2...)
        char_idx = (loop - 1) % 26
        char = chr(65 + char_idx) # 65 là 'A'
        
        current.name = char # Tên trạng thái hiện tại (A, B, C...)
        # Tên trạng thái tiếp theo sẽ là dạng "A1", "B1" tương ứng cha
        next_s.name = f"{char}{successors.index(next_s) + 1}"
        
        # 2. Tính Delta = h(next) - h(current)
        delta = next_s.h - current.h
        
        # 3. Log chi tiết bước lặp 
        # Lấy tên của cha, nếu không có cha (node gốc) thì ghi là "None"
        parent_name = current.parent.name if current.parent else "None"
        
        log_entry = (
            f"Vòng lặp {loop}: T={T:.3f}, State={current.name} | Parent={parent_name} | Action={current.action} | h={current.h}\n"
            f"Ma trận Current:\n{get_matrix_str(current.dirty_cells)}\n"
            f"Xét State Next={next_s.name} | Parent={current.name} | Action={next_s.action} | h={next_s.h}\n"
            f"Ma trận Next:\n{get_matrix_str(next_s.dirty_cells)}"
        )
        steps_log.append(log_entry)
        
        # 4. Logic chấp nhận trạng thái theo xác suất Boltzmann
        if delta < 0: # Nếu trạng thái mới tốt hơn
            current = next_s
            steps_log.append("-> Chấp nhận (h giảm)\n" + "="*30)
        else:
            # Nếu tệ hơn, chấp nhận với xác suất p = exp(-delta/T)
            p = math.exp(-delta / T)
            rand_val = random.random()
            if rand_val < p:
                current = next_s
                steps_log.append(f"-> Chấp nhận xác suất (p={p:.3f}, random={rand_val:.3f})\n" + "="*30)
            else:
                steps_log.append(f"-> Từ chối (p={p:.3f}, random={rand_val:.3f})\n" + "="*30)
        
        path.append(current)
        T *= alpha # Giảm nhiệt độ T = alpha * T
        
        # KIỂM TRA ĐIỀU KIỆN DỪNG THEO YÊU CẦU
        if T <= Tmin:
            steps_log.append(f"-> Nhiệt độ T={T:.3f} đã nhỏ hơn hoặc bằng Tmin={Tmin}. Ngưng thuật toán.")
            break
            
        loop += 1
        
    return path, steps_log

# =========================================================
# HÀM RUN CHÍNH (GIAO DIỆN TKINTER - KHÔNG CHỈNH SỬA)
# =========================================================
def run(center_frame, log_text, result_text, name):
    ROWS, COLS = 3, 3  
    start_pos = (0, 0) 
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_frame.configure(bg="#ffffff")
    for widget in center_frame.winfo_children():
        widget.destroy()

    title_label = tk.Label(center_frame, text="VACUUM WORLD - Local Beam Search", bg="#1a1a1a", fg="#00ffcc", font=("Segoe UI", 20, "bold"), pady=8)
    title_label.pack(side="top", fill="x", pady=(10, 10))

    legend_bar = tk.Frame(center_frame, bg="#1a1a1a", pady=6)
    legend_bar.pack(side="top", fill="x", padx=40, pady=(0, 20))
    center_legend = tk.Frame(legend_bar, bg="#1a1a1a")
    center_legend.pack(anchor="center")
    tk.Label(center_legend, bg="#e0e0e0", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 5))
    tk.Label(center_legend, text="0 = CLEAN CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
    tk.Label(center_legend, bg="#ff6666", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="1 = DIRTY CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")
    tk.Label(center_legend, bg="#3399ff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="BLUE = ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    container = tk.Frame(center_frame, bg="#ffffff")
    container.pack(expand=True)
    CELL_SIZE = 100
    canvas = tk.Canvas(container, width=COLS * CELL_SIZE, height=ROWS * CELL_SIZE, bg="#ffffff", highlightthickness=0)
    canvas.pack(side="bottom")

    path, steps_log = simulated_annealing(start_pos, initial_dirty, ROWS, COLS)
    
    log_text.delete("1.0", tk.END)
    for log_block in steps_log:
        log_text.insert(tk.END, log_block + "\n\n")
    log_text.see(tk.END) 
    log_text.update_idletasks()

    result_text.delete("1.0", tk.END)
    if not path or len(path) == 0:
        result_text.insert(tk.END, "Kết quả: KHÔNG TÌM THẤY ĐƯỜNG ĐI!")
        return

    path_names = [node.name for node in path]
    path_coords = [str(node.agent_pos) for node in path]
    result_text.insert(tk.END, "=== FINAL SOLUTION ===\n\n")
    result_text.insert(tk.END, f"Lộ trình các nút:\n{' -> '.join(path_names)}\n\n")
    result_text.insert(tk.END, f"Tọa độ di chuyển:\n{' -> '.join(path_coords)}\n\n")
    
    last_node = path[-1]
    if last_node.is_goal():
        result_text.insert(tk.END, "TRẠNG THÁI: THÀNH CÔNG (Đã dọn sạch)!")
    else:
        result_text.insert(tk.END, "TRẠNG THÁI: BỊ KẸT (Cực trị địa phương)!")
        
    def draw_state(state, step_index):
        canvas.delete("all")
        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                is_dirty = (r, c) in state.dirty_cells
                if (r, c) == state.agent_pos:
                    cell_bg, text_color, width_border = "#3399ff", "white", 3
                else:
                    cell_bg, text_color, width_border = ("#ff6666", "white", 1) if is_dirty else ("#e0e0e0", "#444444", 1)
                canvas.create_rectangle(x1, y1, x2, y2, fill=cell_bg, outline="white", width=width_border)
                canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2, text="1" if is_dirty else "0", fill=text_color, font=("Consolas", 20, "bold"))
                if (r, c) == state.agent_pos:
                    canvas.create_text(x1 + CELL_SIZE/2, y1 + CELL_SIZE/2 + 18, text="ROBOT", fill="white", font=("Segoe UI", 10, "bold"))
        if step_index > 0:
            for i in range(step_index):
                r1, c1 = path[i].agent_pos
                r2, c2 = path[i+1].agent_pos
                canvas.create_line(c1*CELL_SIZE + CELL_SIZE/2, r1*CELL_SIZE + CELL_SIZE/2, c2*CELL_SIZE + CELL_SIZE/2, r2*CELL_SIZE + CELL_SIZE/2, fill="#0022cc", width=4, arrow=tk.LAST)

    def animate(step_index):
        if step_index < len(path):
            draw_state(path[step_index], step_index)
            center_frame.after(600, lambda: animate(step_index + 1))
    animate(0)