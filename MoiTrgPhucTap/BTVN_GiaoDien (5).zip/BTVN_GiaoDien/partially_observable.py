#https://github.com/nguyenhoangphuongnhu12/Tri_Tue_Nhan_Tao
#Nguyễn Hoàng Phương Như - 24110042
#THUẬT TOÁN TÌM KIẾM TRONG MÔI TRƯỜNG NHÌN THẤY MỘT PHẦN (ÁP DỤNG BFS)
import tkinter as tk
from collections import deque

# =========================================================
# HÀM BỔ TRỢ: XUẤT MA TRẬN THEO DẠNG DÒNG X CỘT TRỰC QUAN
# =========================================================
def get_matrix_multiline_str(dirty_cells_set, rows=3, cols=3):
    lines = []
    for r in range(rows):
        row_str = []
        for c in range(cols):
            row_str.append("1" if (r, c) in dirty_cells_set else "0")
        lines.append("      " + " ".join(row_str))
    return "\n".join(lines)


# =========================================================
# HÀM TỰ ĐỘNG SINH TÊN THEO THỨ TỰ: A-Z, A1-Z1, A2-Z2,...
# =========================================================
def name_generator():
    letters = [chr(i) for i in range(65, 91)] # 'A' -> 'Z'
    for letter in letters:
        yield letter
    suffix = 1
    while True:
        for letter in letters:
            yield f"{letter}{suffix}"
        suffix += 1


# =========================================================
# 1. LỚP BIỂU DIỄN TRẠNG THÁI ĐƠN LẺ (SINGLE STATE)
# =========================================================
class VacuumState:
    def __init__(self, agent_pos, dirty_cells):
        self.agent_pos = agent_pos                # Tọa độ (r, c)
        self.dirty_cells = frozenset(dirty_cells) # Tập các ô bẩn

    def __eq__(self, other):
        return self.agent_pos == other.agent_pos and self.dirty_cells == other.dirty_cells

    def __hash__(self):
        return hash((self.agent_pos, self.dirty_cells))

    def get_detailed_str(self):
        matrix_block = get_matrix_multiline_str(self.dirty_cells, rows=3, cols=3)
        return f"   + Robot ở vị trí {self.agent_pos}\n   + Sơ đồ ma trận ô bẩn:\n{matrix_block}"

    # Đọc tri giác tại ô hiện tại: 1 nếu bẩn, 0 nếu sạch
    def get_percept(self):
        return 1 if self.agent_pos in self.dirty_cells else 0

    def transition(self, action, rows, cols):
        r, c = self.agent_pos
        new_dirty = set(self.dirty_cells)
        
        if action == "U" and r > 0: r -= 1
        elif action == "D" and r < rows - 1: r += 1
        elif action == "L" and c > 0: c -= 1
        elif action == "R" and c < cols - 1: c += 1
        
        # Tự động hút bụi ngầm khi robot vừa chuyển sang ô mới
        if (r, c) in new_dirty:
            new_dirty.remove((r, c))
            
        return VacuumState((r, c), new_dirty)


# =========================================================
# 2. LỚP NÚT TẬP NIỀM TIN (BELIEF-STATE NODE CHO BFS)
# =========================================================
class BeliefNode:
    def __init__(self, states, parent=None, action=None, step=0, name="A", percept_trigger=None):
        self.states = frozenset(states) 
        self.parent = parent            
        self.action = action            
        self.step = step                
        self.name = name                 
        self.percept_trigger = percept_trigger 

    def get_key(self):
        return self.states


# =========================================================
# 3. THUẬT TOÁN TÌM KIẾM TRONG MÔI TRƯỜNG NHÌN THẤY MỘT PHẦN (ÁP DỤNG BFS)
# =========================================================
def partially_observable_bfs(rows, cols, initial_dirty):
    """
    Duyệt BFS không gian niềm tin kết hợp phân rã tri giác cảm biến (AND-OR Graph Search).
    """
    gen = name_generator()
    steps_log = []
    
    # KHỞI TẠO TẬP NIỀM TIN BAN ĐẦU (Chưa biết Start -> 9 vị trí khả thi)
    all_positions = [(r, c) for r in range(rows) for c in range(cols)]
    start_states = []
    for pos in all_positions:
        r, c = pos
        new_dirty = set(initial_dirty)
        if (r, c) in new_dirty:
            new_dirty.remove((r, c))
        start_states.append(VacuumState(pos, new_dirty))
        
    root_node = BeliefNode(states=start_states, parent=None, action=None, step=0, name=next(gen))
    
    # Khởi tạo Frontier và Reached
    frontier = deque([root_node])
    reached = set()
    
    actions_list = ["U", "D", "L", "R"]
    solution_nodes = [] 
    
    init_log = f"[KHỞI TẠO HỆ THỐNG PARTIAL OBS BFS]\n"
    init_log += f"-> [PUSH] Đẩy nút Gốc [{root_node.name}] vào Frontier.\n"
    init_log += f"- Tập niềm tin ban đầu chứa đầy đủ {len(root_node.states)} cấu hình giả định.\n"
    steps_log.append(init_log)

    while frontier:
        # [POP] Lấy nút ra khỏi đầu hàng đợi duyệt
        curr_node = frontier.popleft()
        curr_key = curr_node.get_key()
        
        if curr_key in reached:
            continue
        reached.add(curr_key)
        
        log_msg = f"==> [POP] Lấy nút [{curr_node.name}] ra khỏi Frontier (Step {curr_node.step})\n"
        log_msg += f"Đã thêm [{curr_node.name}] vào tập REACHED (Đã thăm).\n"
        if curr_node.parent:
            per_str = "DIRTY (1)" if curr_node.percept_trigger == 1 else "CLEAN (0)"
            log_msg += f"- Sinh từ nút cha: [{curr_node.parent.name}] -> Hành động: [{curr_node.action}] -> Nhận cảm biến: [{per_str}]\n"
        log_msg += f"- Kích thước Tập niềm tin hiện tại: {len(curr_node.states)} trạng thái khả thi.\n"
        log_msg += f"- MA TRẬN CÁC TRẠNG THÁI GIẢ ĐỊNH (DÒNG x CỘT):\n"
        
        sorted_states = sorted(list(curr_node.states), key=lambda x: (x.agent_pos, len(x.dirty_cells)))
        for idx, state in enumerate(sorted_states, 1):
            log_msg += f"Trạng thái giả định {idx}:\n{state.get_detailed_str()}\n"
            
        log_msg += f"Frontier={len(frontier)} | Reached={len(reached)}\n"
        log_msg += f"------------------------------------------------------------\n"
        
        # KIỂM TRA ĐIỀU KIỆN ĐÍCH THEO YÊU CẦU:
        # Chỉ cần ô (1,0) và (1,1) đều sạch (không nằm trong s.dirty_cells)
        is_goal_reached = False
        for s in curr_node.states:
            if ((1, 0) not in s.dirty_cells) and ((1, 1) not in s.dirty_cells):
                is_goal_reached = True
                break

        if is_goal_reached:
            log_msg += f"[MỤC TIÊU ĐẠT ĐƯỢC] Tập niềm tin [{curr_node.name}] thỏa mãn: Cả hai ô (1,0) và (1,1) đã sạch bụi!"
            steps_log.append(log_msg)
            
            # Truy vết ngược chuỗi các nút dẫn đến thành công
            temp = curr_node
            while temp is not None:
                solution_nodes.append(temp)
                temp = temp.parent
            solution_nodes.reverse()
            return solution_nodes, steps_log
            
        # SINH CON QUA CÁC HÀNH ĐỘNG DI CHUYỂN (Nhánh OR)
        push_log_actions = []
        for action in actions_list:
            moved_states = set()
            for state in curr_node.states:
                moved_states.add(state.transition(action, rows, cols))
                
            # PHÂN TÁCH THEO TRI GIÁC CẢM BIẾN THỰC TẾ (Nhánh AND)
            for percept in [0, 1]:
                filtered_states = [s for s in moved_states if s.get_percept() == percept]
                
                if not filtered_states:
                    continue
                    
                child_node = BeliefNode(
                    states=filtered_states,
                    parent=curr_node,
                    action=action,
                    step=curr_node.step + 1,
                    name="", 
                    percept_trigger=percept
                )
                
                child_key = child_node.get_key()
                if child_key not in reached:
                    child_node.name = next(gen)
                    frontier.append(child_node) # [PUSH] nút con vào Frontier
                    
                    p_status = "CLEAN (0)" if percept == 0 else "DIRTY (1)"
                    push_log_actions.append(f"Hành động [{action}] + Cảm biến [{p_status}] -> Sinh nút [{child_node.name}] ({len(filtered_states)} trạng thái)")
                    
        if push_log_actions:
            log_msg += "[PUSH] Các nút nhánh rẽ cảm biến hợp lệ được đẩy vào Frontier:\n"
            for act_msg in push_log_actions:
                log_msg += f"   + {act_msg}\n"
        else:
            log_msg += "[DEAD-END] Tất cả các hướng đi từ nút này đều lặp hoặc rơi vào ngõ cụt!\n"
            
        steps_log.append(log_msg)
        
    return None, steps_log


# =========================================================
# 4. HÀM RUN CHÍNH (GIAO DIỆN TKINTER ĐỒ HỌA)
# =========================================================
def run(center_frame, log_text, result_text, name):
    ROWS, COLS = 3, 3  
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_frame.configure(bg="#ffffff")

    for widget in center_frame.winfo_children():
        widget.destroy()

    log_text.delete("1.0", tk.END)
    result_text.delete("1.0", tk.END)

    title_label = tk.Label(
        center_frame, 
        text="VACUUM WORLD - Partially Observable Search (BFS)", 
        bg="#1a1a1a", 
        fg="#00ffcc", 
        font=("Segoe UI", 16, "bold"), 
        pady=8
    )
    title_label.pack(side="top", fill="x", pady=(10, 10))

    legend_bar = tk.Frame(center_frame, bg="#1a1a1a", pady=6)
    legend_bar.pack(side="top", fill="x", padx=40, pady=(0, 20))

    center_legend = tk.Frame(legend_bar, bg="#1a1a1a")
    center_legend.pack(anchor="center")

    tk.Label(center_legend, bg="#e0e0e0", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 5))
    tk.Label(center_legend, text="0 = CLEAN", bg="#1a1a1a", fg="white", font=("Segoe UI", 9, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#ff6666", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="1 = DIRTY", bg="#1a1a1a", fg="white", font=("Segoe UI", 9, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#99ccff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="LIGHT BLUE = MAYBE ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 9, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#0055ff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="DARK BLUE = CONFIRMED ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 9, "bold")).pack(side="left")

    container = tk.Frame(center_frame, bg="#ffffff")
    container.pack(expand=True)

    CELL_SIZE = 100
    canvas = tk.Canvas(
        container, 
        width=COLS * CELL_SIZE, 
        height=ROWS * CELL_SIZE, 
        bg="#ffffff", 
        highlightthickness=0
    )
    canvas.pack(side="bottom")

    # Thực thi thuật toán BFS
    path, steps_log = partially_observable_bfs(ROWS, COLS, initial_dirty)
    
    for log_block in steps_log:
        log_text.insert(tk.END, log_block + "\n" + "="*75 + "\n")
    log_text.see(tk.END) 
    log_text.update_idletasks()

    if not path:
        result_text.insert(tk.END, "Kết quả: THẤT BẠI! Không tìm thấy chuỗi hành động đạt mục tiêu.")
        return

    path_names = [node.name for node in path]
    actions_taken = [f"{node.action}(Cảm biến:{node.percept_trigger})" for node in path if node.action is not None]
    
    result_text.insert(tk.END, "=== FINAL SOLUTION (PARTIAL OBS BFS) ===\n\n")
    result_text.insert(tk.END, f"Chuỗi nút tối ưu đạt đích nhanh nhất:\n{' -> '.join(path_names)}\n\n")
    result_text.insert(tk.END, f"Kịch bản chuỗi hành động + Nhận tri giác cảm biến:\n{' -> '.join(actions_taken)}\n\n")
    result_text.insert(tk.END, f"Tổng số bước di chuyển (step): {path[-1].step} bước\n\n")
    result_text.insert(tk.END, f"TRẠNG THÁI ĐẦU RA: THÀNH CÔNG!\n(Hai ô mục tiêu (1,0) và (1,1) đã được quét dọn sạch sẽ hoàn toàn).")
    result_text.tag_config("success", foreground="green")
    result_text.tag_add("success", "1.0", "end")

    confirmed_history = []

    # =========================================================
    # HÀM CẬP NHẬT GIAO DIỆN VẼ MA TRẬN & ĐƯỜNG ĐI LIÊN TUYẾN
    # =========================================================
    def draw_belief_node(belief_node, current_index):
        canvas.delete("all")
        
        possible_positions = set(state.agent_pos for state in belief_node.states)
        all_dirty_cells = set()
        for state in belief_node.states:
            all_dirty_cells.update(state.dirty_cells)
        
        current_action = belief_node.action if belief_node.action else "START"

        # Ghi vết lịch sử ô XANH ĐẬM phục vụ vẽ nét mũi tên liên tuyến xuyên tâm
        if len(possible_positions) == 1:
            pos = list(possible_positions)[0]
            if len(confirmed_history) <= current_index:
                confirmed_history.append(pos)
        else:
            if len(confirmed_history) <= current_index:
                confirmed_history.append(None)

        # Tiến hành vẽ ma trận ô lưới
        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                
                is_dirty = (r, c) in all_dirty_cells
                is_possible_agent = (r, c) in possible_positions
                
                # Làm nổi bật viền của hai ô mục tiêu (1,0) và (1,1) bằng màu vàng lục để dễ theo dõi
                is_target_cell = (r, c) in [(1, 0), (1, 1)]
                
                if is_possible_agent:
                    if len(possible_positions) == 1:
                        cell_bg = "#0055ff"       
                        text_color = "white"
                    else:
                        cell_bg = "#99ccff"       
                        text_color = "black"
                    cell_outline = "#22aa22" if is_target_cell else "#ffffff"
                    width_border = 4 if is_target_cell else 3
                else:
                    if is_dirty:
                        cell_bg = "#ff6666"       
                        text_color = "white"
                        cell_outline = "#cc5252"
                    else:
                        cell_bg = "#e0e0e0"       
                        text_color = "#444444"
                        cell_outline = "#22aa22" if is_target_cell else "#b8b8b8"
                    width_border = 3 if is_target_cell else 1

                canvas.create_rectangle(x1, y1, x2, y2, fill=cell_bg, outline=cell_outline, width=width_border)
                
                # In mốc nhãn chữ TARGET nhỏ tại hai ô này để đánh dấu
                if is_target_cell:
                    canvas.create_text(x1 + 32, y1 + 15, text="TARGET", fill="darkgreen", font=("Segoe UI", 8, "bold"))

                matrix_val = "1" if is_dirty else "0"
                canvas.create_text(
                    x1 + CELL_SIZE/2, 
                    y1 + CELL_SIZE/2 - 10 if is_possible_agent else y1 + CELL_SIZE/2, 
                    text=matrix_val, 
                    fill=text_color, 
                    font=("Consolas", 20, "bold")
                )
                
                if is_possible_agent:
                    label_text = "ROBOT" if len(possible_positions) == 1 else "MAYBE"
                    canvas.create_text(
                        x1 + CELL_SIZE/2, 
                        y1 + CELL_SIZE/2 + 18, 
                        text=label_text, 
                        fill=text_color, 
                        font=("Segoe UI", 9, "bold")
                    )

        # Vẽ mũi tên liên chuỗi thắt nút xuyên tâm giống hệt hình mẫu
        for i in range(current_index):
            p1 = confirmed_history[i]
            p2 = confirmed_history[i+1]
            if p1 is not None and p2 is not None:
                r1, c1 = p1
                r2, c2 = p2
                line_x1 = c1 * CELL_SIZE + CELL_SIZE / 2
                line_y1 = r1 * CELL_SIZE + CELL_SIZE / 2
                line_x2 = c2 * CELL_SIZE + CELL_SIZE / 2
                line_y2 = r2 * CELL_SIZE + CELL_SIZE / 2
                canvas.create_line(line_x1, line_y1, line_x2, line_y2, fill="#0022cc", width=4, arrow=tk.LAST, arrowshape=(10, 12, 4))


    # =========================================================
    # ĐIỀU KHIỂN HOẠT ẢNH ANIMATION TỪNG BƯỚC LỘ TRÌNH
    # =========================================================
    def animate(step_index):
        if step_index < len(path):
            current_node = path[step_index]
            draw_belief_node(current_node, step_index)
            center_frame.after(1000, lambda: animate(step_index + 1)) 

    confirmed_history.clear()
    animate(0)