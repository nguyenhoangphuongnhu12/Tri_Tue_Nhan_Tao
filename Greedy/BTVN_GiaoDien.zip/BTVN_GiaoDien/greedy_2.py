#https://github.com/nguyenhoangphuongnhu12/Tri_Tue_Nhan_Tao
#Nguyễn Hoàng Phương Như - 24110042
#Thuật toán Greedy với h(n) = số ô rác còn lại
import tkinter as tk
import copy
import heapq

# =========================================================
# BIẾN TOÀN CỤC & HÀM ĐẶT TÊN NÚT TỰ ĐỘNG (A, B, C... A1, B1...)
# =========================================================
node_name_counter = 0

def generate_next_node_name():
    global node_name_counter
    #Xác định quay vòng bảng chữ cái bao nhiêu lần (nếu vòng 1 thì => A1, B1..)
    cycle = node_name_counter // 26
    #Xác định vị trí chữ cái trong bảng (từ 0 đến 25).
    index = node_name_counter % 26
    char = chr(65 + index)  # 65 là mã ASCII của chữ 'A'
    node_name_counter += 1
    return f"{char}{cycle}" if cycle > 0 else char

# =========================================================
# LỚP BIỂU DIỄN TRẠNG THÁI MÁY HÚT BỤI
# =========================================================
class VacuumState:
    def __init__(self, agent_pos, dirty_cells, parent=None, action=None, step=0, name="S"):
        self.agent_pos = agent_pos       # Tọa độ máy hiện tại (dòng, cột)
        self.dirty_cells = set(dirty_cells)  # Tập hợp các ô đang có rác (dòng, cột)
        self.parent = parent             # Trạng thái cha để truy vết đường đi
        self.action = action             # Hành động dẫn đến trạng thái này ('U', 'D', 'L', 'R')
        self.step = step               # Độ sâu cây tìm kiếm (số bước đã đi)
        self.name = name                 # Đặt tên tự động định danh nút
        self.h = 0                       # Giá trị Heuristic (Số ô bẩn còn lại)

    # Hàm đặc biệt để heapq biết cách so sánh các đối tượng.
    # Khi dùng heappush/heappop, Python sẽ dựa vào đây để xác định 
    # nút nào có 'h' nhỏ hơn thì nút đó có độ ưu tiên cao hơn (đứng trước).
    def __lt__(self, other):
        if self.h != other.h:
            return self.h < other.h
        return self.step < other.step # Ưu tiên nút có số bước nhỏ hơn (nút sinh ra sớm hơn)
    
    # Kiểm tra xem đã dọn sạch toàn bộ bản đồ chưa
    def is_goal(self):
        return len(self.dirty_cells) == 0

    # Chuyển trạng thái thành tuple để lưu vào tập Reached
    def get_tuple(self):
        # Chuyển set => list => tuple
        return (self.agent_pos, tuple(sorted(list(self.dirty_cells))))

    # Sinh các trạng thái con kết hợp đặt tên tự động dùng hàm global
    def generate_successors(self, rows, cols):
        successors = []
        r, c = self.agent_pos
        
        # Thứ tự hướng đi cố định chỉ mục: U, D, L, R
        moves = [
            ("U", r - 1, c),
            ("D", r + 1, c),
            ("L", r, c - 1),
            ("R", r, c + 1),
        ]
        
        for action, nr, nc in moves:
            if 0 <= nr < rows and 0 <= nc < cols:
                new_dirty = copy.deepcopy(self.dirty_cells)
                if (nr, nc) in new_dirty:
                    new_dirty.remove((nr, nc))
                
                # Tạo tên mới theo kiểu A, B, C...
                child_name = generate_next_node_name()
                
                successors.append(VacuumState(
                    agent_pos=(nr, nc), 
                    dirty_cells=new_dirty, 
                    parent=self, 
                    action=action, 
                    step=self.step + 1,
                    name=child_name
                ))
        return successors


# =========================================================
# HÀM TÍNH HEURISTIC (Số ô bẩn còn lại)
# =========================================================
def calculate_heuristic(agent_pos, dirty_cells):
    return len(dirty_cells)


# =========================================================
# HÀM BỔ TRỢ: CHUYỂN TRẠNG THÁI THÀNH MA TRẬN CHỮ ĐỂ IN LOG
# =========================================================
def get_matrix_str(dirty_cells, rows=3, cols=3):
    lines = []
    for r in range(rows):
        row_str = []
        for c in range(cols):
            row_str.append("1" if (r, c) in dirty_cells else "0")
        lines.append(" ".join(row_str))
    return "\n".join(lines)


# =========================================================
# THUẬT TOÁN TÌM KIẾM THAM LAM (GREEDY BEST-FIRST SEARCH)
# =========================================================
def greedy_search(start_pos, initial_dirty, rows, cols):
    global node_name_counter
    node_name_counter = 0 # Reset bộ đếm tên khi bắt đầu tìm kiếm
    
    start_dirty = copy.deepcopy(initial_dirty)
    if start_pos in start_dirty:
        start_dirty.remove(start_pos)
        
    start_state = VacuumState(start_pos, start_dirty, name="S") 
    start_state.step = 0
    start_state.h = calculate_heuristic(start_pos, start_dirty)

    frontier = [start_state]  
    reached = {}             
    steps_log = []           
    

    while frontier:
        # Dùng heappop để lấy nút h nhỏ nhất
        current = heapq.heappop(frontier)
        
        if current.get_tuple() in reached:
            continue
        
        # POP ra rồi thì mới chính thức đưa vào reached (Đã thăm)
        reached[current.get_tuple()] = [current.h, current.name]

        if current.parent:
            parent_info = f"{current.parent.name}"
        else:
            parent_info = "None"

        # 1. GHI LOG CHO THÔNG TIN NÚT ĐANG ĐƯỢC LẤY RA (POP)
        log_chunk = []
        log_chunk.append(f"[POP] NODE: {current.name} (Robot = {current.agent_pos})")
        log_chunk.append(f"Parent: {parent_info}")
        log_chunk.append(f"Action: {current.action}")
        log_chunk.append(f"Step : {current.step}")
        log_chunk.append(f"h(n) : {current.h} (Khoảng cách Heuristic)")
        log_chunk.append("\n" + get_matrix_str(current.dirty_cells, rows, cols) + "\n")

        if current.is_goal():
            log_chunk.append(f"-> NODE {current.name} ĐẠT TRẠNG THÁI ĐÍCH (GOAL STATE)!\n")
            
            log_chunk.append("REACHED (Danh sách các tên nút đã thăm):")
            reached_formatted = [f"{info[1]} (h={info[0]})" for info in reached.values()]
            log_chunk.append(f"  [{', '.join(reached_formatted)}]")
            log_chunk.append("\n" + "="*50 + "\n")
            steps_log.append("\n".join(log_chunk))
            
            path = []
            while current:
                path.append(current)
                current = current.parent
            return path[::-1], steps_log

        # Sinh các nút con (EXPAND)
        successors = current.generate_successors(rows, cols)
        log_chunk.append("EXPAND:")
        
        for successor in successors:
            successor.step = current.step + 1
            state_tuple = successor.get_tuple()
            
            # Kiểm tra xem trạng thái đã nằm trong Reached chưa
            # VÀ kiểm tra xem có đang nằm trong Frontier (danh sách list) không
            in_frontier = any(node.get_tuple() == state_tuple for node in frontier)
            
            if state_tuple not in reached and not in_frontier:
                successor.h = calculate_heuristic(successor.agent_pos, successor.dirty_cells)
                frontier.append(successor)
                
                log_chunk.append(f"  PUSH Node {successor.name} | Parent = {successor.parent.name} | Action = {successor.action} | Step = {successor.step} | h = {successor.h}")
                log_chunk.append(get_matrix_str(successor.dirty_cells, rows, cols) + "\n")
        

        # 2. GHI LOG DANH SÁCH FRONTIER HIỆN TẠI
        log_chunk.append("FRONTIER (Các nút trong hàng đợi xếp từ bé đến lớn):")
        if not frontier:
            log_chunk.append("  [Trống]")
        else:
            for node in sorted(frontier):
                p_name = node.parent.name if node.parent else "None"
                log_chunk.append(f"  Node {node.name} | Parent = {p_name} | Action = {node.action} | Step = {node.step} | h = {node.h}")
                log_chunk.append(get_matrix_str(node.dirty_cells, rows, cols) + "\n")
                
        # 3. GHI LOG DANH SÁCH REACHED
        log_chunk.append("REACHED (Danh sách các tên nút đã thăm):")
        reached_formatted = [f"{info[1]} (h={info[0]})" for info in reached.values()]
        log_chunk.append(f"  [{', '.join(reached_formatted)}]")
        
        log_chunk.append("\n" + "="*50 + "\n")
        steps_log.append("\n".join(log_chunk))
                
    return None, steps_log


# =========================================================
# HÀM RUN CHÍNH (GIAO DIỆN TKINTER)
# =========================================================
def run(center_frame, log_text, result_text, name):
    ROWS, COLS = 3, 3  
    start_pos = (0, 0) 
    initial_dirty = [(0, 1), (1, 0), (1, 1), (2, 2)] 

    center_frame.configure(bg="#ffffff")

    for widget in center_frame.winfo_children():
        widget.destroy()

    log_text.delete("1.0", tk.END)
    result_text.delete("1.0", tk.END)

    # Tiêu đề trên ma trận
    title_label = tk.Label(
        center_frame, 
        text="VACUUM WORLD - GREEDY h(n) = Số ô bẩn còn lại", 
        bg="#1a1a1a", 
        fg="#00ffcc", 
        font=("Segoe UI", 20, "bold"), 
        pady=8
    )
    title_label.pack(side="top", fill="x", pady=(10, 10))

    # Khung chú thích màu sắc
    legend_bar = tk.Frame(center_frame, bg="#1a1a1a", pady=6)
    legend_bar.pack(side="top", fill="x", padx=40, pady=(0, 20))

    center_legend = tk.Frame(legend_bar, bg="#1a1a1a")
    center_legend.pack(anchor="center")

    tk.Label(center_legend, bg="#e0e0e0", width=3, relief="solid", bd=1).pack(side="left", padx=(15, 5))
    tk.Label(center_legend, text="0 = CLEAN CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#ff6666", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="1 = DIRTY CELL", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    tk.Label(center_legend, bg="#3399ff", width=3, relief="solid", bd=1).pack(side="left", padx=(25, 5))
    tk.Label(center_legend, text="BLUE = ROBOT", bg="#1a1a1a", fg="white", font=("Segoe UI", 10, "bold")).pack(side="left")

    # Khung chứa Canvas vẽ ma trận
    container = tk.Frame(center_frame, bg="#ffffff")
    container.pack(expand=True)

    CELL_SIZE = 100
    canvas = tk.Canvas(
        container, 
        width=COLS * CELL_SIZE, 
        height=ROWS * CELL_SIZE, 
        bg="#ffffff", 
        highlightthickness=0
    )
    canvas.pack(side="bottom")

    # Chạy thuật toán tìm kiếm tham lam
    path, steps_log = greedy_search(start_pos, initial_dirty, ROWS, COLS)

    for log_block in steps_log:
        log_text.insert(tk.END, log_block + "\n")
    log_text.see("1.0")

    if not path:
        result_text.insert(tk.END, "KHÔNG TÌM THẤY ĐƯỜNG ĐI!")
        return

    # In chuỗi tên Node lộ trình dọn dẹp cuối cùng lên màn hình Final Solution
    path_names = [node.name for node in path]
    path_coords = [str(node.agent_pos) for node in path]
    
    result_text.insert(tk.END, f"Chuỗi các Nút di chuyển:\n" + " -> ".join(path_names) + "\n\n")
    result_text.insert(tk.END, f"Tọa độ đường đi dọn dẹp:\n" + " -> ".join(path_coords))

    # =========================================================
    # HÀM CẬP NHẬT GIAO DIỆN VẼ MA TRẬN & ĐƯỜNG NỐI
    # =========================================================
    def draw_state(state, step_index):
        canvas.delete("all")
        
        # Vẽ nền ma trận
        for r in range(ROWS):
            for c in range(COLS):
                x1, y1 = c * CELL_SIZE, r * CELL_SIZE
                x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE
                
                is_dirty = (r, c) in state.dirty_cells
                matrix_val = "1" if is_dirty else "0"
                
                if (r, c) == state.agent_pos:
                    cell_bg = "#3399ff"    
                    text_color = "white"
                    cell_outline = "#ffffff"
                    width_border = 3
                else:
                    if is_dirty:
                        cell_bg = "#ff6666" 
                        text_color = "white"
                        cell_outline = "#cc5252"
                    else:
                        cell_bg = "#e0e0e0" 
                        text_color = "#444444"
                        cell_outline = "#b8b8b8"
                    width_border = 1

                canvas.create_rectangle(x1, y1, x2, y2, fill=cell_bg, outline=cell_outline, width=width_border)
                
                canvas.create_text(
                    x1 + CELL_SIZE/2, 
                    y1 + CELL_SIZE/2 - 10 if (r, c) == state.agent_pos else y1 + CELL_SIZE/2, 
                    text=matrix_val, 
                    fill=text_color, 
                    font=("Consolas", 20, "bold")
                )
                
                if (r, c) == state.agent_pos:
                    canvas.create_text(
                        x1 + CELL_SIZE/2, 
                        y1 + CELL_SIZE/2 + 18, 
                        text="ROBOT", 
                        fill="white", 
                        font=("Segoe UI", 10, "bold")
                    )

        # Vẽ nét đường đi màu xanh đậm
        if step_index > 0:
            for i in range(step_index):
                r1, c1 = path[i].agent_pos
                r2, c2 = path[i+1].agent_pos
                
                line_x1 = c1 * CELL_SIZE + CELL_SIZE / 2
                line_y1 = r1 * CELL_SIZE + CELL_SIZE / 2
                line_x2 = c2 * CELL_SIZE + CELL_SIZE / 2
                line_y2 = r2 * CELL_SIZE + CELL_SIZE / 2
                
                canvas.create_line(line_x1, line_y1, line_x2, line_y2, fill="#0022cc", width=4, arrow=tk.LAST)

    # Vòng lặp animation
    def animate(step_index):
        if step_index < len(path):
            current_state = path[step_index]
            draw_state(current_state, step_index)
            center_frame.after(600, lambda: animate(step_index + 1))

    animate(0)